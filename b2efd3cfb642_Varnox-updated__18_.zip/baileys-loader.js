'use strict'

let loaded

// The socket library published by the same author as the button helper.
// All socket requires in the bot now point at blacklord-baileys.
// so an existing install keeps working.
// blacklord-baileys is the socket library, and package.json also aliases the
// legacy name to it:
// so blacklord_lib/myfunc.js and helper/listeners.js - which require that name
// and destructure { proto, delay, getContentType } at load time - get the real
// package rather than a shim.
const SOCKET_PACKAGES = ['blacklord-baileys', '@whiskeysockets/baileys']

async function importSocketPackage() {
  const errors = []
  for (const name of SOCKET_PACKAGES) {
    try {
      return await import(name)
    } catch (err) {
      errors.push(`${name}: ${err && err.code ? err.code : err && err.message}`)
    }
  }
  throw new Error(
    `Could not load a WhatsApp socket library. Tried ${SOCKET_PACKAGES.join(', ')}.\n` +
    `Run: npm install blacklord-baileys\nAttempts:\n  ${errors.join('\n  ')}`
  )
}

async function loadBaileys() {
  if (loaded) return loaded
  const mod = await importSocketPackage()
  loaded = { ...mod, default: mod.default || mod.makeWASocket }

  // Compatibility helpers expected by this CommonJS bot.
  if (!loaded.fetchLatestBaileysVersion) {
    loaded.fetchLatestBaileysVersion = async () => ({ version: [2, 3000, 0], isLatest: true })
  }
  if (!loaded.makeCacheableSignalKeyStore) {
    loaded.makeCacheableSignalKeyStore = (keys) => keys
  }
  if (!loaded.areJidsAnimeMdUser) {
    loaded.areJidsAnimeMdUser = loaded.areJidsSameUser || ((a, b) => String(a || '') === String(b || ''))
  }

  global.Baileys = loaded
  return loaded
}

module.exports = { loadBaileys }
