'use strict'
/*
 * varnox.part3.js  —  external command part (3 of 4)
 *
 * Commands declared in the `commands` map below are picked up by varnox.js
 * automatically. See the header of varnox.part1.js for the full guide, the list
 * of values each handler receives, and the rules to follow.
 *
 * Handy when a command needs to send media rather than text — use the socket
 * directly, because `reply()` is for text:
 *
 *     module.exports = {
 *         commands: {
 *             shot: async ({ Blacklord, m, reply }) => {
 *                 const buffer = await someImageFetch()
 *                 await Blacklord.sendMessage(m.chat, { image: buffer, caption: 'done' }, { quoted: m })
 *             },
 *         }
 *     }
 */
module.exports = {
    commands: {

        // ── add your commands here ──────────────────────────────────────────

    }
}
