const { generateWAMessageFromContent, prepareWAMessageMedia } = global.Baileys || {}

const btn = {
  url(display_text, url, merchant_url) {
    return {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({
        display_text,
        url,
        merchant_url: merchant_url || url
      })
    }
  },

  copy(display_text, copy_code) {
    return {
      name: 'cta_copy',
      buttonParamsJson: JSON.stringify({ display_text, copy_code })
    }
  },

  call(display_text, phone_number) {
    return {
      name: 'cta_call',
      buttonParamsJson: JSON.stringify({ display_text, phone_number })
    }
  },

  reply(display_text, id) {
    return {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text, id })
    }
  },

  list(list_button_text, sections) {
    return {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({ title: list_button_text, sections })
    }
  }
}

async function sendButtons(sock, jid, options = {}, sendOptions = {}) {
  const {
    text = '',
    footer = '',
    title = '',
    subtitle = '',
    image,
    buttons,
    interactiveButtons,
    contextInfo,
    quoted
  } = options

  const resolvedButtons = buttons || interactiveButtons || []
  if (!Array.isArray(resolvedButtons) || resolvedButtons.length === 0) {
    throw new Error('blacklord-btns: at least one button is required')
  }

  for (const button of resolvedButtons) {
    if (!button || typeof button.name !== 'string' || typeof button.buttonParamsJson !== 'string') {
      throw new Error('blacklord-btns: invalid button; use btn.url, btn.reply, btn.copy, btn.call, or btn.list')
    }
  }

  let preparedImage = null
  if (image) {
    preparedImage = await prepareWAMessageMedia(
      { image },
      { upload: sock.waUploadToServer }
    )
  }

  const messageContent = {
    interactiveMessage: {
      header: {
        title: String(title || ''),
        subtitle: String(subtitle || ''),
        hasMediaAttachment: Boolean(preparedImage),
        ...(preparedImage?.imageMessage ? { imageMessage: preparedImage.imageMessage } : {})
      },
      ...(text ? { body: { text: String(text) } } : {}),
      ...(footer ? { footer: { text: String(footer) } } : {}),
      ...(contextInfo ? { contextInfo } : {}),
      nativeFlowMessage: {
        buttons: resolvedButtons,
        messageParamsJson: '',
        messageVersion: 1
      }
    }
  }

  const fullMessage = generateWAMessageFromContent(jid, messageContent, {
    quoted: quoted || sendOptions.quoted,
    userJid: sock.user?.id
  })

  const interactiveStanzaNodes = [
    {
      tag: 'biz',
      attrs: {},
      content: [
        {
          tag: 'interactive',
          attrs: { type: 'native_flow', v: '1' },
          content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
        }
      ]
    }
  ]

  await sock.relayMessage(jid, fullMessage.message, {
    messageId: fullMessage.key.id,
    additionalNodes: interactiveStanzaNodes,
    ...sendOptions
  })

  return fullMessage
}

/**
 * Send a reliable plain-text or image-caption response, omitting interactive
 * metadata. Same call shape as sendButtons.
 */
async function sendRaw(sock, jid, options = {}) {
  const { text = '', image, caption, contextInfo, quoted } = options
  const message = image
    ? { image, caption: caption ?? text, ...(contextInfo ? { contextInfo } : {}) }
    : { text, ...(contextInfo ? { contextInfo } : {}) }
  return sock.sendMessage(jid, message, { quoted })
}

/**
 * Send native-flow buttons, or the raw equivalent when `format` is
 * 'raw'/'text'/'plain'. With `fallbackRaw` enabled a native-flow failure
 * degrades to raw instead of throwing.
 */
async function sendCompatible(sock, jid, options = {}) {
  const { format = 'native', fallbackRaw = false, ...payload } = options
  if (['raw', 'text', 'plain'].includes(String(format).toLowerCase())) {
    return sendRaw(sock, jid, payload)
  }
  try {
    return await sendButtons(sock, jid, payload)
  } catch (error) {
    if (!fallbackRaw) throw error
    return sendRaw(sock, jid, payload)
  }
}

module.exports = {
  btn,
  sendButtons,
  sendInteractiveMessage: sendButtons,
  sendRaw,
  sendCompatible
}
