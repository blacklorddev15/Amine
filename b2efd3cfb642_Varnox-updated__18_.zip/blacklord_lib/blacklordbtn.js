'use strict'
/*
 * Unified button backend for every bundled command.
 *
 * The bundled commands were written against the legacy varnoxbtns package,
 * which is not declared in package.json, so `require("varnoxbtns")` always
 * failed and every command silently fell back to plain text.
 *
 * package.json now declares the published Blacklord packages:
 *
 *   blacklord-bttns   latest   interactive-buttons helper
 *   blacklord-baileys latest   socket library (used by baileys-loader.js)
 *
 * blacklord-bttns exports `sendInteractiveMessage` (an alias of sendButtons),
 * which is exactly the call shape the bundled commands use, so it is preferred.
 * It ships as ESM, so on Node versions that cannot require() ESM the attempt
 * throws and we fall back to the bundled CJS implementation in
 * blacklordBtns.js, which is kept at parity with blacklord-bttns 1.4.0.
 *
 * Preference order: blacklord-bttns -> wolfbtns -> gifted-btns -> bundled lib.
 */
const local = require('./blacklordBtns.js')

const CANDIDATES = ['blacklord-bttns', 'wolfbtns', 'gifted-btns']

function resolveBackend() {
    for (const name of CANDIDATES) {
        try {
            const mod = require(name)
            if (!mod) continue
            if (typeof mod.sendInteractiveMessage === 'function') return { mod, name, method: 'sendInteractiveMessage' }
            if (typeof mod.sendButtons === 'function') return { mod, name, method: 'sendButtons' }
        } catch (e) {
            /* not installed - try the next one */
        }
    }
    return { mod: local, name: 'blacklord_lib/blacklordBtns', method: 'sendInteractiveMessage' }
}

const backend = resolveBackend()

/* Commands pass buttons in two shapes: native flow ({name, buttonParamsJson})
 * and a shorthand ({display, id}). Only native flow is accepted downstream, so
 * the shorthand is converted here. */
function toNativeButton(button) {
    if (!button || typeof button !== 'object') return null
    if (typeof button.name === 'string' && typeof button.buttonParamsJson === 'string') return button
    const display = button.display ?? button.display_text ?? button.text ?? button.title
    const id = button.id ?? button.buttonId ?? button.value ?? button.command
    if (!display && !id) return null
    return local.btn.reply(String(display || id), String(id || display))
}

function normaliseButtons(input) {
    const list = Array.isArray(input) ? input : input ? [input] : []
    return list.map(toNativeButton).filter(Boolean)
}

async function sendInteractiveMessage(sock, jid, options = {}, sendOptions = {}) {
    const opts = { ...options }
    const buttons = normaliseButtons(options.interactiveButtons ?? options.buttons)
    if (!buttons.length) throw new Error('blacklord-btns: no usable button supplied')
    opts.buttons = buttons
    opts.interactiveButtons = buttons
    const fn = typeof backend.mod[backend.method] === 'function' ? backend.mod[backend.method] : null
    if (fn) return fn.call(backend.mod, sock, jid, opts, sendOptions)
    return local.sendButtons(sock, jid, opts, sendOptions)
}

module.exports = {
    sendInteractiveMessage,
    sendButtons: sendInteractiveMessage,
    sendCompatible: sendInteractiveMessage,
    normaliseButtons,
    toNativeButton,
    btn: local.btn,
    backend: backend.name
}
