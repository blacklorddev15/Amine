const fs = require('fs')
const path = require('path')

const databaseDir = path.join(__dirname, '..', 'database')
const stickerCommandsPath = path.join(databaseDir, 'sticker_commands.json')
const prefixFreePath = path.join(databaseDir, 'prefixfree.json')
const displayModesPath = path.join(databaseDir, 'display_modes.json')

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch {
    return fallback
  }
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true })
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2))
}

function normalizeSessionId(sessionId) {
  return String(sessionId || 'default').replace(/[^a-zA-Z0-9_.-]/g, '_') || 'default'
}

function getStickerStore() {
  const value = readJson(stickerCommandsPath, {})
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function getStickerCommands(sessionId = 'default') {
  const store = getStickerStore()
  const key = normalizeSessionId(sessionId)
  const value = store[key]
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function setStickerCommand(sessionId, hash, command) {
  const store = getStickerStore()
  const key = normalizeSessionId(sessionId)
  if (!store[key] || typeof store[key] !== 'object' || Array.isArray(store[key])) store[key] = {}
  if (command) store[key][hash] = command
  else delete store[key][hash]
  if (!Object.keys(store[key]).length) delete store[key]
  writeJson(stickerCommandsPath, store)
  return store
}

function getStickerCommand(sessionId, hash) {
  return getStickerCommands(sessionId)[hash] || null
}

function getPrefixFree() {
  return readJson(prefixFreePath, { enabled: false })?.enabled === true
}

function setPrefixFree(enabled) {
  writeJson(prefixFreePath, { enabled: Boolean(enabled) })
  return Boolean(enabled)
}

function normalizeDisplayMode(mode) {
  return String(mode || '').toLowerCase() === 'iphone' ? 'iphone' : 'android'
}

function getDisplayMode(sessionId = 'default') {
  const modes = readJson(displayModesPath, {})
  const key = normalizeSessionId(sessionId)
  return normalizeDisplayMode(modes[key] || 'android')
}

function setDisplayMode(sessionId = 'default', mode = 'android') {
  const modes = readJson(displayModesPath, {})
  const key = normalizeSessionId(sessionId)
  modes[key] = normalizeDisplayMode(mode)
  writeJson(displayModesPath, modes)
  return modes[key]
}

module.exports = {
  getStickerCommands,
  setStickerCommand,
  getStickerCommand,
  getPrefixFree,
  setPrefixFree,
  getDisplayMode,
  setDisplayMode
}
