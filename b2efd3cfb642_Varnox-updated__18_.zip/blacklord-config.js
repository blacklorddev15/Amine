const fs = require('fs');
const path = require('path');

// Contact details
global.sessionid = process.env.SESSION_ID || '';
global.ytname = process.env.YT_NAME || "YT: @_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_";
global.socialm = process.env.SOCIAL_M || "Telegram: _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_";
global.location = process.env.LOCATION || "Nigeria, Port Harcourt";

// Creator details
global.ownernumber = process.env.OWNER_NUMBER || '2347047504860';
global.ownername = process.env.OWNER_NAME || 'VARNOX';
global.botname = process.env.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';

// Menu image rotation. Add one or more comma-separated local filesystem paths.
// Paths may be relative to the project root or absolute. A different local image
// is selected each time the menu command is opened.
global.menuImagePaths = (process.env.MENU_IMAGE_PATHS || 'database/menu-images/menu-1.jpg,database/menu-images/menu-2.jpg,database/menu-images/menu-3.jpg,database/menu-images/menu-4.jpg,database/menu-images/menu-5.jpg,database/menu-images/menu-6.jpg')
    .split(',')
    .map(filePath => filePath.trim())
    .filter(Boolean)
    .map(filePath => path.resolve(__dirname, filePath));

// Telegram pairing settings. Set TELEGRAM_BOT_TOKEN in .env, or place it here locally.
global.telegramToken = process.env.TELEGRAM_BOT_TOKEN || '';
global.telegramAllowedUsers = (process.env.TELEGRAM_ALLOWED_USERS || '').split(',').map(v => v.trim()).filter(Boolean);

// Font style used by lib/font.js's bold() helper.
// 'bold'        -> WhatsApp markdown bold: *text*  (default, safest)
// 'boldUnicode' -> Unicode bold characters, works outside markdown too
global.fontStyle = process.env.FONT_STYLE || 'bold';

// Single source of truth for the "forwarded from channel" info that
// gets attached to bot responses (contextInfo.forwardedNewsletterMessageInfo).
// Every place in the bot that used to hardcode a newsletter jid/name
// now reads global.newsletterJid / global.newsletterName instead —
// change it once here and it updates everywhere.
global.newsletterJid = process.env.NEWSLETTER_JID || '120363407629340544@newsletter';
global.newsletterName = process.env.NEWSLETTER_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';

// Default settings 
global.prefix = process.env.PREFIX || '.';
// Settings: true=enable false=disable
global.autoRecording = process.env.AUTO_RECORDING === 'true';
global.autoTyping = process.env.AUTO_TYPING === 'true';
global.autorecordtype = process.env.AUTO_RECORD_TYPE === 'true';
global.autoread = process.env.AUTO_READ === 'true';
global.autobio = process.env.AUTO_BIO !== 'false';
global.autoviewstatus = process.env.AUTO_VIEW_STATUS !== 'false';
global.welcome = process.env.WELCOME !== 'false';
global.autoreact = process.env.AUTO_REACT === 'true';
global.autolikestatus = process.env.AUTO_LIKE_STATUS === 'true';
global.autoOffline = process.env.AUTO_OFFLINE === 'true';

// Default emoji
global.themeemoji = process.env.THEME_EMOJI || '👨‍💻';


// Sticker details
global.packname = process.env.PACKNAME || 'Sticker By';
global.author = process.env.AUTHOR || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_\n\nContact: +2347047504860';
// Default settings 2
global.wm = process.env.WM || "_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_";
global.link = process.env.LINK || 'https://whatsapp.com/channel/0029VaXaqHII1rcmdDBBsd3g';

// Reply messages
global.mess = {
    done: '✅ Task completed successfully!',
    prem: '⚠️ Access denied. This feature is for premium users only.',
    admin: '⚠️ Only group admins can use this command.',
    botAdmin: '⚠️ I need to be a group admin to use this command.',
    owner: '⛔ Command restricted to the bot owner.',
    group: 'ℹ️ This command can only be used in group chats.',
    private: 'ℹ️ This command can only be used in private chats.',
    wait: '⏳ Processing your request... Please wait a moment.',
    error: '❌ An unexpected error occurred. Please try again later.',
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`Updated: ${__filename}`);
    delete require.cache[file];
    require(file);
});
