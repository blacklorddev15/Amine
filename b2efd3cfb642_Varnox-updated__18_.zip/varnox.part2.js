'use strict'
/*
 * varnox.part2.js  —  external command part (2 of 4)
 *
 * Commands declared in the `commands` map below are picked up by varnox.js
 * automatically. See the header of varnox.part1.js for the full guide, the list
 * of values each handler receives, and the rules to follow.
 *
 * Quick reminder: the key is the command name as typed after the prefix, and
 * anything you need beyond the handler's arguments must be required above.
 *
 *     const axios = require('axios')       // if your command needs it
 *
 *     module.exports = {
 *         commands: {
 *             stats: async ({ reply }) => {
 *                 await reply(`Uptime: ${process.uptime().toFixed(0)}s`)
 *             },
 *         }
 *     }
 */
module.exports = {
    commands: {

        // ── add your commands here ──────────────────────────────────────────

    }
}
