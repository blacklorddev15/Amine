/*
 * Varnox command adapter.
 *
 * This file intentionally replaces only the WhatsApp command layer. The
 * protected index.js remains responsible for the socket, session,
 * website integration, and message event lifecycle.
 */
'use strict'

require('./blacklord-config')

const { smsg } = require('./blacklord_lib/myfunc')
let blacklordHandler
function installSocketCompatibility(sock) {
  if (typeof sock.decodeJid !== 'function') {
    sock.decodeJid = jid => jid || ''
  }

  if (typeof sock.sendText !== 'function') {
    sock.sendText = (jid, text, quoted, options = {}) =>
      sock.sendMessage(jid, { text: String(text ?? '') }, { quoted, ...options })
  }

  if (typeof sock.sendMedia !== 'function') {
    sock.sendMedia = (jid, data, type = 'file', filename = '', quoted, options = {}) => {
      const content = Buffer.isBuffer(data)
        ? { document: data, fileName: filename || 'file', mimetype: 'application/octet-stream' }
        : { document: data, fileName: filename || 'file', mimetype: 'application/octet-stream' }
      return sock.sendMessage(jid, content, { quoted, ...options })
    }
  }
}

async function handleMessage(sock, rawMessage, chatMeta = {}) {
  if (!rawMessage) return

  installSocketCompatibility(sock)
  const message = smsg(sock, rawMessage, null)
  // Normalize every WhatsApp button/list/native-flow callback into command text.
  // This keeps the main dispatcher independent of Baileys message-shape differences.
  const callback = message?.body || message?.text || (() => {
    try {
      const raw = message?.msg?.nativeFlowResponseMessage?.paramsJson
      const parsed = raw ? (typeof raw === 'string' ? JSON.parse(raw) : raw) : {}
      return parsed.id || parsed.selectedRowId || parsed.selectedId || parsed.command || message?.msg?.selectedId || ''
    } catch { return '' }
  })()
  const callbackTypes = ['listResponseMessage', 'buttonsResponseMessage', 'templateButtonReplyMessage', 'interactiveResponseMessage']
  if (callbackTypes.includes(message?.mtype) && callback) {
    // Remember that this text came from a button/list tap. The dispatcher needs
    // this flag because mtype is rewritten to 'conversation' below, which would
    // otherwise hide the fact that the id is a bare command with no prefix.
    message.isButtonResponse = true
    message.text = String(callback)
    message.body = String(callback)
    message.message = { conversation: String(callback) }
    message.mtype = 'conversation'
    message.msg = { conversation: String(callback) }
  }
  message.pushName = rawMessage.pushName || message.pushName || ''
  message.chatMeta = chatMeta

  if (typeof message.reply !== 'function') {
    message.reply = (text, chatId = message.chat, options = {}) =>
      sock.sendMessage(chatId, { text: String(text ?? '') }, { quoted: message, ...options })
  }

  if (!blacklordHandler) blacklordHandler = require('./varnox')
  return blacklordHandler(sock, message, chatMeta, null)
}

// Preserve the original connection automation contract.
async function runAutoFollow(sock) {
  let settings = {}
  try { settings = require('./settings') } catch {}

  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    try { await sock.newsletterFollow(nl) } catch (error) {
      process.stdout.write(`[autofollow] ${nl} => ${error.message}\\n`)
    }
  }

  for (const link of (settings.AUTO_JOIN_GROUPS || [])) {
    try {
      const code = String(link).split('chat.whatsapp.com/')[1]
      if (code) await sock.groupAcceptInvite(code)
    } catch (error) {
      process.stdout.write(`[autojoin] ${link} => ${error.message}\\n`)
    }
  }
}

module.exports = {
  handleMessage,
  runAutoFollow,
  CMDS: {},
}
