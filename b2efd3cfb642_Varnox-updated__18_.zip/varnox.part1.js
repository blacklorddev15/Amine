'use strict'
/*
 * varnox.part1.js  —  external command part (1 of 4)
 * ============================================================================
 *
 * Move command blocks out of varnox.js and into this file so the dispatcher
 * stays manageable. varnox.js loads varnox.part1..4.js automatically:
 * anything declared here is registered as a command, shows up in the menus and
 * in .allcommands, and menu buttons for it dispatch correctly.
 *
 * ── how to move a command out ───────────────────────────────────────────────
 *
 * 1. In varnox.js find the block you want to move:
 *
 *        case 'greet': {
 *            if (!text) return reply('Give me a name.')
 *            await reply(`👋 Hello ${text}!`)
 *        }
 *        break
 *
 * 2. Delete it from varnox.js — the whole thing, including the `case` line,
 *    the braces and the trailing `break`.
 *
 * 3. Paste the inside of it here:
 *
 *        greet: async ({ reply, text }) => {
 *            if (!text) return reply('Give me a name.')
 *            await reply(`👋 Hello ${text}!`)
 *        },
 *
 * That's it. Nothing else to register.
 *
 * ── what the handler receives ───────────────────────────────────────────────
 *
 *   Blacklord   the socket (already wrapped in the VARNOX reply styling)
 *   m           the message object
 *   prefix      the command prefix, e.g. '.'
 *   command     the command name that was sent
 *   reply(x)    send a text reply in the standard VARNOX box
 *   text        everything after the command, as a string
 *   args        text split on spaces, as an array
 *   sender      the sender's jid
 *   from        the chat jid
 *   q           alias of text (kept for copied code)
 *   isGroup     true when the chat is a group
 *   isCreator   true for the bot owner / paired account
 *   pushname    the sender's display name
 *   quoted      the quoted message, when the user replied to one
 *   isMedia     true when the quoted message is image/video/sticker/audio
 *
 * ── rules ───────────────────────────────────────────────────────────────────
 *
 *   • the key is the command name exactly as typed after the prefix
 *   • keep this file at the bot root — relative requires such as
 *     './blacklord_lib/blacklordBtns.js' resolve from the file's own folder, so
 *     moving it into a subfolder would break them
 *   • anything the body needs beyond the values above (axios, fs, ffmpeg, ...)
 *     must be required at the top of this file
 *   • a command may only exist once — if the same name is still in varnox.js,
 *     the one in varnox.js wins and this copy is ignored with a console warning
 *   • `reply()` wraps text in the VARNOX box automatically; menus are excluded
 *     from that box, so send menu output through sendMenuButtons instead
 */
module.exports = {
    commands: {

// ── MOVED FROM varnox.js: the menu shortcuts ────────────────────────────────
        ownermenu: async ({ sendCategoryMenu }) => sendCategoryMenu('OWNER', 'OWNER MENU'),
        settingsmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('OWNER', 'OWNER MENU'),
        groupmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('GROUP', 'GROUP MENU'),
        utilitymenu: async ({ sendCategoryMenu }) => sendCategoryMenu('UTILITY', 'UTILITY MENU'),
        stickermenu: async ({ sendCategoryMenu }) => sendCategoryMenu('UTILITY', 'UTILITY MENU'),
        funmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('FUN', 'FUN MENU'),
        adminmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('ADMIN', 'ADMIN MENU'),
        animemenu: async ({ sendCategoryMenu }) => sendCategoryMenu('ANIME', 'ANIME MENU'),
        ephotomenu: async ({ sendCategoryMenu }) => sendCategoryMenu('EPHOTO', 'EPHOTO MENU'),
        aimenu: async ({ sendCategoryMenu }) => sendCategoryMenu('AI', 'AI MENU'),
        downloadsmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('DOWNLOADS', 'DOWNLOADS MENU'),
        downloadmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('DOWNLOADS', 'DOWNLOADS MENU'),
        generalmenu: async ({ sendCategoryMenu }) => sendCategoryMenu('GENERAL', 'GENERAL MENU'),
        general_system: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('SYSTEM', getGeneralSubcategoryCommands('SYSTEM')),
        general_group_tools: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('GROUP TOOLS', getGeneralSubcategoryCommands('GROUP_TOOLS')),
        general_economy: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('ECONOMY', getGeneralSubcategoryCommands('ECONOMY')),
        general_sports: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('SPORTS', getGeneralSubcategoryCommands('SPORTS')),
        general_contacts_social: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('CONTACTS & SOCIAL', getGeneralSubcategoryCommands('CONTACTS_SOCIAL')),
        general_media_creative: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('MEDIA & CREATIVE', getGeneralSubcategoryCommands('MEDIA_CREATIVE')),
        general_downloads: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('DOWNLOADS', getGeneralSubcategoryCommands('DOWNLOADS')),
        general_ai_chat: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('AI CHAT', getGeneralSubcategoryCommands('AI_CHAT')),
        general_ai_image_code: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('AI IMAGE & CODE', getGeneralSubcategoryCommands('AI_IMAGE_CODE')),
        general_security_network: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('SECURITY & NETWORK', getGeneralSubcategoryCommands('SECURITY_NETWORK')),
        general_games_entertainment: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('GAMES & ENTERTAINMENT', getGeneralSubcategoryCommands('GAMES_ENTERTAINMENT')),
        general_notes_productivity: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('NOTES & PRODUCTIVITY', getGeneralSubcategoryCommands('NOTES_PRODUCTIVITY')),
        general_miscellaneous: async ({ sendCommandListMenu, getGeneralSubcategoryCommands }) => sendCommandListMenu('MISCELLANEOUS', getGeneralSubcategoryCommands('MISCELLANEOUS')),

// ── MOVED FROM varnox.js: the menu shortcuts ────────────────────────────────


        // ── add your commands here, for example: ────────────────────────────
        //
        // greet: async ({ reply, text }) => {
        //     if (!text) return reply('Give me a name.')
        //     await reply(`👋 Hello ${text}!`)
        // },

    }
}
