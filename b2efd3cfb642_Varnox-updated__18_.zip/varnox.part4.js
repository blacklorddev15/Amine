'use strict'
/*
 * varnox.part4.js  —  external command part (4 of 4)
 *
 * Commands declared in the `commands` map below are picked up by varnox.js
 * automatically. See the header of varnox.part1.js for the full guide, the list
 * of values each handler receives, and the rules to follow.
 *
 * Owner-only commands can check isCreator themselves:
 *
 *     module.exports = {
 *         commands: {
 *             restart: async ({ isCreator, reply, Blacklord, m }) => {
 *                 if (!isCreator) return reply('Owner only.')
 *                 await reply('Restarting...')
 *                 process.exit(0)
 *             },
 *         }
 *     }
 *
 * Note: a command name may only exist once. If a part declares a name that is
 * still handled inside varnox.js, the varnox.js version wins and the copy here
 * is skipped with a console warning, so it is safe to move blocks over
 * gradually - nothing silently breaks.
 */
module.exports = {
    commands: {

        // ── add your commands here ──────────────────────────────────────────

    }
}
