const { spawn } = require("child_process");
if (process.argv[2] !== "--child") {
    
    function launch() {
        let p = spawn("node", ["index.js", "--child"], {
            stdio: ["inherit", "inherit", "inherit", "ipc"]
        });
        
        p.on("message", (msg) => {
            if (msg === "reset") {
                p.kill();
                launch();
            }
        });
        
        p.on("exit", (code) => {
            if (code === 0 || code === 1) launch();
        });
    }
    launch();
    return;
}
const path = require('path');
const fs = require('fs');
require('./config')
if (!fs.existsSync(__dirname + '/session/creds.json') && global.sessionid) {
    try {
        const sessionData = JSON.parse(global.sessionid);
        fs.mkdirSync(__dirname + '/session', { recursive: true });
        fs.writeFileSync(__dirname + '/session/creds.json', JSON.stringify(sessionData, null, 2));
    } catch (err) {
    }
}
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const chalk = require('chalk')
const FileType = require('file-type')
const axios = require('axios')
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, sleep, reSize, getGroupAdmins } = require('./lib/myfunc')
const { default: AnimeMdConnect, delay, PHONENUMBER_MCC, makeCacheableSignalKeyStore, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, proto } = require("baileys")
const NodeCache = require("node-cache")
const Pino = require("pino")
const readline = require("readline")
const { parsePhoneNumber } = require("libphonenumber-js")
const makeWASocket = require("baileys").default
const AnimeMdHandler = require("./AnimeMd")
const setupConsoleFilters = require('./lib/filter')
const { fetchGithubJSON, FILES } = require('./lib/github')
const http = require('http')
setupConsoleFilters()
const PORT = process.env.PORT || 3000;
const INDEX_PATH = path.join(__dirname, 'lib', 'index.html');
http.createServer((req, res) => {
    fs.readFile(INDEX_PATH, (err, data) => {
        if (err) {
            res.writeHead(404);
            return res.end('Not found');
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
    });
}).listen(PORT, "0.0.0.0", () => {});

const store = {
    messages: {},
    contacts: {},
    chats: {},
    groupMetadata: async (jid) => {
        return {}
    },
    bind: function(ev) {
        ev.on('messages.upsert', ({ messages }) => {
            messages.forEach(msg => {
                if (msg.key && msg.key.remoteJid) {
                    this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {}
                    this.messages[msg.key.remoteJid][msg.key.id] = msg
                }
            })
        })
        
        ev.on('contacts.update', (contacts) => {
            contacts.forEach(contact => {
                if (contact.id) {
                    this.contacts[contact.id] = contact
                }
            })
        })
        
        ev.on('chats.set', (chats) => {
            this.chats = chats
        })
    },
    loadMessage: async function (jid, id) {
    return this.messages[jid]?.[id] || null
    }
}
let phoneNumber = "2347047504860"
let owner = JSON.parse(fs.readFileSync('./database/owner.json'))
let connectedMessageSent = false

const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

async function startAnimeMd() {
let { version, isLatest } = await fetchLatestBaileysVersion()
const {  state, saveCreds } =await useMultiFileAuthState(`./session`)
    const msgRetryCounterCache = new NodeCache()
    const groupMetadataCache = new NodeCache({ stdTTL: 5 * 60, useClones: false })
    const handledMessages = new Set()
    const BOT_START_TIME = Date.now()
    const AnimeMd = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: !pairingCode, 
        browser: [ "Ubuntu", "Chrome", "20.0.04" ],
        auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" }).child({ level: "fatal" })),
      },
	  fireInitQueries: false,
      markOnlineOnConnect: false, 
      generateHighQualityLinkPreview: true, 
      syncFullHistory: false,
	  shouldSyncHistoryMessage: () => false,
      getMessage: async (key) => {
      const msg = await store.loadMessage(key.remoteJid, key.id)
      return msg?.message || undefined
     },
      msgRetryCounterCache,
      cachedGroupMetadata: async (jid) => groupMetadataCache.get(jid),
      defaultQueryTimeoutMs: undefined,
   })
   const _rawGroupMetadata = AnimeMd.groupMetadata.bind(AnimeMd)
   AnimeMd.groupMetadata = async (jid) => {
       const cached = groupMetadataCache.get(jid)
       if (cached) return cached
       try {
           const fresh = await _rawGroupMetadata(jid)
           if (fresh) groupMetadataCache.set(jid, fresh)
           return fresh
       } catch (err) {
           return {}
       }
   }
   AnimeMd.ev.on('groups.update', (updates) => {
       for (const update of updates) {
           if (update?.id) {
               groupMetadataCache.del(update.id)
           }
       }
   })
   AnimeMd.ev.on('group-participants.update', ({ id }) => {
       if (id) groupMetadataCache.del(id)
   })

   store.bind(AnimeMd.ev)

   if (pairingCode && !AnimeMd.authState.creds.registered) {
      if (useMobile) throw new Error('Cannot use pairing code with mobile api')

      let phoneNumber
      if (!!phoneNumber) {
         phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

         if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
            console.log(chalk.bgBlack(chalk.redBright("Start with country code of your WhatsApp Number, Example : +2347047504860")))
            process.exit(0)
         }
      } else {
         phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Please type your number below 🥰.\nFor example +2347047504860: `)))
         phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

         // Ask again when entering the wrong number
         if (phoneNumber == "rien" ){
            console.log(chalk.bgBlack(chalk.redBright("Start with country code of your WhatsApp Number, Example : +2347047504860")))

            phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Please type your WhatsApp number. 🥰\nFor example: +2347047504860 : `)))
            phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
            rl.close()
         }
      }

      setTimeout(async () => {
         let code = await AnimeMd.requestPairingCode(phoneNumber)
         code = code?.match(/.{1,4}/g)?.join("-") || code
         console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)))
      }, 3000)
   }
//AUTO STATUS WATCHER//
const processedStatusMessages = new Set()
function resolveStatusTarget(AnimeMd, mek) {
    const candidates = [
        mek?.key?.participantPn,
        mek?.participantPn,
        mek?.key?.participant,
        mek?.participant,
        mek?.sender,
        mek?.key?.remoteJid
    ].filter(Boolean)
    for (let jid of candidates) {
        if (AnimeMd.decodeJid) jid = AnimeMd.decodeJid(jid)
        if (jid?.endsWith('@s.whatsapp.net')) return jid
    }
    for (let jid of candidates) {
        if (AnimeMd.decodeJid) jid = AnimeMd.decodeJid(jid)
        if (jid) return jid
    }
    return null
}

async function handleStatusWatcher(AnimeMd, mek) {
    try {
        if (!mek?.message || !mek?.key || mek.key.fromMe) return
        if (mek.key.remoteJid !== 'status@broadcast') return
        if (!global.autoviewstatus && !global.autolikestatus) return

        const msg = mek.message

        if (msg?.reactionMessage) return
        if (msg?.protocolMessage) return

        const msgId = mek.key.id

        if (processedStatusMessages.has(msgId)) return
        processedStatusMessages.add(msgId)

        setTimeout(() => {
            processedStatusMessages.delete(msgId)
        }, 5 * 60 * 1000)

        const participantJid = resolveStatusTarget(AnimeMd, mek)
        if (!participantJid) return

        const statusKey = {
            remoteJid: 'status@broadcast',
            id: msgId,
            fromMe: false,
            participant: participantJid
        }

        if (global.autoviewstatus) {
            await AnimeMd.readMessages([statusKey])
            console.log(`👀 Viewed status from ${participantJid}`)
        }

        if (!global.autolikestatus) return

        const emojis = [
            '❤️','💸','😇','🍂','💥','💯','🔥','💫','💎','💗',
            '🤍','🖤','👀','🙌','🙆','🚩','🥰','💐','😎','🤎',
            '✅','⚡','🧡','😁','😄','🌸','🕊️','🌷','⛅','🌟',
            '🗿','☠️','💜','💙','🌝','💚'
        ]

        const emoji = emojis[Math.floor(Math.random() * emojis.length)]

        await AnimeMd.sendMessage(
            'status@broadcast',
            {
                react: {
                    text: emoji,
                    key: statusKey
                }
            },
            {
                statusJidList: [participantJid]
            }
        )

        console.log(`✅ Reacted to status from ${participantJid} with ${emoji}`)

    } catch (err) {
        console.error('❌ Status handler error:', err.message)
    }
}
//ANTISTATUS GROUP WATCHER//
async function handleAntiStatus(AnimeMd, mek) {
    try {
        if (!mek?.message || !mek?.key) return

        const from = mek.key.remoteJid
        if (!from || !from.endsWith('@g.us')) return

        const sender = mek.key.participant || from

        if (!mek.message?.groupStatusMentionMessage) return

        let data = {}
        try {
            data = JSON.parse(fs.readFileSync('./database/antistatus.json', 'utf8'))
        } catch {}

        if (!data[from]?.enabled) return

        const metadata = await AnimeMd.groupMetadata(from)
        const admins = metadata.participants
            .filter(v => v.admin !== null)
            .map(v => v.id)

        if (mek.key.fromMe || admins.includes(sender)) return

        const mode = data[from].mode || 'warn'
        const limit = data[from].limit || 3

        if (!data[from].users) data[from].users = {}
        if (!data[from].users[sender]) data[from].users[sender] = 0

        data[from].users[sender] += 1

        await AnimeMd.sendMessage(from, { delete: mek.key })

        if (mode === 'delete') {
            await AnimeMd.sendMessage(from, {
                text: `⚠️ @${sender.split('@')[0]} status mention not allowed.`,
                mentions: [sender]
            }, { quoted: mek })
        }

        if (mode === 'warn') {
            const count = data[from].users[sender]

            await AnimeMd.sendMessage(from, {
                text: `⚠️ Warning ${count}/${limit} @${sender.split('@')[0]}`,
                mentions: [sender]
            }, { quoted: mek })
        }

        if (mode === 'warnkick') {
            const count = data[from].users[sender]

            if (count >= limit) {
                await AnimeMd.groupParticipantsUpdate(from, [sender], 'remove')

                await AnimeMd.sendMessage(from, {
                    text: `🚫 @${sender.split('@')[0]} removed (limit ${limit}).`,
                    mentions: [sender]
                }, { quoted: mek })

                data[from].users[sender] = 0
            } else {
                await AnimeMd.sendMessage(from, {
                    text: `⚠️ Warning ${count}/${limit}`,
                    mentions: [sender]
                }, { quoted: mek })
            }
        }

        if (mode === 'kick') {
            await AnimeMd.groupParticipantsUpdate(from, [sender], 'remove')

            await AnimeMd.sendMessage(from, {
                text: `🚫 @${sender.split('@')[0]} removed for status mention.`,
                mentions: [sender]
            }, { quoted: mek })
        }

        fs.writeFileSync('./database/antistatus.json', JSON.stringify(data, null, 2))

    } catch (err) {
        console.error('AntiStatus Error:', err.message)
    }
}
// AUTOREACT MESSAGE
const emojiFile = path.join(__dirname, './database/autoreact.json')
let emojis = []

function loadEmojis() {
    try {
        const data = fs.readFileSync(emojiFile, 'utf8')
        const parsed = JSON.parse(data)

        if (!Array.isArray(parsed)) throw new Error('Emoji file is not an array')

        emojis = parsed
    } catch (err) {
        emojis = []
        console.error('❌ Failed to load autoreact emojis:', err.message)
    }
}

loadEmojis()

async function handleAutoReact(AnimeMd, mek) {
    try {
        if (!mek?.key || mek.key.fromMe || !mek.key.remoteJid) return
        if (!global.autoreact || emojis.length < 1) return

        const jid = mek.key.remoteJid
        if (jid === 'status@broadcast') return

        const chatType = jid.endsWith('@g.us') ? 'Group' : 'DM'
        const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)]

        await AnimeMd.sendMessage(jid, {
            react: {
                text: randomEmoji,
                key: mek.key
            }
        })

        console.log(`✅ Auto-reacted in ${chatType} (${jid}) with ${randomEmoji}`)

    } catch (err) {
        console.error('❌ Auto-react error:', err.message)
    }
}
//CHATBOT CODES//
const chatbotProcessedMessages=new Set()
async function handleChatbot(AnimeMd,mek){
    try{
        if(!mek?.message||!mek?.key||mek.key.fromMe)return
        const from=mek.key.remoteJid
        if(!from||from==='status@broadcast')return
        const messageKey=`${from}:${mek.key.id}`
        if(chatbotProcessedMessages.has(messageKey))return
        chatbotProcessedMessages.add(messageKey)
        setTimeout(()=>chatbotProcessedMessages.delete(messageKey),60000)
        let chatbotData={global:false,dm:false,group:false,chats:{}}
        try{
            const data=fs.readFileSync('./database/chatbot.json','utf8')
            chatbotData=JSON.parse(data)
        }catch{
            return
        }
        const isGroup=from.endsWith('@g.us')
        const isDM=from.endsWith('@s.whatsapp.net')
        const chatEnabled=chatbotData.chats?.[from]===true
        const typeEnabled=isGroup?chatbotData.group===true:chatbotData.dm===true
        if(!chatbotData.global&&!typeEnabled&&!chatEnabled)return
        const text=mek.message.conversation||mek.message.extendedTextMessage?.text||mek.message.imageMessage?.caption||mek.message.videoMessage?.caption||''
        if(!text.trim())return
        const prefix=global.prefix||'.'
        if(text.trim().startsWith(prefix))return
        const sender=mek.key.participant||from
        global.userChats=global.userChats||{}
        global.userChatTimestamps=global.userChatTimestamps||{}
        global.userChats[sender]=global.userChats[sender]||[]
        global.userChatTimestamps[sender]=Date.now()
        global.userChats[sender].push(`User: ${text}`)
        if(global.userChats[sender].length>15)global.userChats[sender].shift()
        const history=global.userChats[sender].join('\n').slice(-3000)
        const basePrompt=`
You're ${botname}, an intelligent assistant developed by ${ownername}. Respond clearly and naturally. Do not ask, "How can I assist you?"

Owner: ${ownername}
WhatsApp: https://wa.me/${ownernumber}
GitHub: https://github.com/jamesmodz

Services Guide:
- If someone requests a song, reply: ".play [song name]".
- If someone requests a video, reply: ".video [video name]".
- If someone requests an image, reply: ".img [image name]".
- If someone requests menu, reply: ".menu".
- If someone requests a song, reply: ".song [song name]".

Conversation History:
${history}
        `.trim()
        await AnimeMd.sendPresenceUpdate('composing',from)
        await new Promise(resolve=>setTimeout(resolve,1000))
        const apiUrl=`https://eliteprotech-apis.zone.id/deepai?prompt=${encodeURIComponent(text)}`
        const response=await axios.get(apiUrl,{headers:{Accept:'*/*','User-Agent':'Mozilla/5.0'},timeout:30000})
        const botReply=response?.data?.success&&response?.data?.response?response.data.response:'I couldn’t generate a reply at this time. Please try again.'
        await AnimeMd.sendPresenceUpdate('paused',from)
        global.userChats[sender].push(`Bot: ${botReply}`)
        if(global.userChats[sender].length>15)global.userChats[sender].shift()
        await AnimeMd.sendMessage(from,{text:botReply},{quoted:mek})
    }catch(err){
        console.error('❌ Chatbot Error:',err.message)
        try{
            const from=mek?.key?.remoteJid
            if(from)await AnimeMd.sendMessage(from,{text:'❌ An error occurred while processing your message.'},{quoted:mek})
        }catch(fallbackErr){
            console.error('❌ Failed to send error message:',fallbackErr.message)
        }
    }
}
setInterval(()=>{
    if(!global.userChatTimestamps||!global.userChats)return
    const now=Date.now()
    for(const user in global.userChatTimestamps){
        if(now-global.userChatTimestamps[user]>30*60*1000){
            delete global.userChats[user]
            delete global.userChatTimestamps[user]
            console.log(`🧹 Cleared memory for inactive user: ${user}`)
        }
    }
},10*60*1000)
//ANTILINK DETECT//
async function handleAntiLink(AnimeMd, mek) {
    try {
        if (!mek?.message || !mek?.key) return
        if (mek.message.protocolMessage) return
        const from = mek.key.remoteJid
        if (!from || !from.endsWith('@g.us')) return
        const sender = mek.key.participant || from
        const text =
            mek.message.conversation ||
            mek.message.extendedTextMessage?.text ||
            mek.message.imageMessage?.caption ||
            mek.message.videoMessage?.caption ||
            mek.message.documentMessage?.caption ||
            ''
        if (!isUrl(text)) return
        let antilinkData = {}
        try {
            antilinkData = JSON.parse(
                fs.readFileSync('./database/antilink.json', 'utf8')
            )
        } catch (err) {
            console.error('Error loading antilink.json:', err.message)
            return
        }
        if (!antilinkData[from]?.enabled) return
        const actionType = antilinkData[from].action || 'warn'
        const warnings = antilinkData[from].warnings || {}
        const groupMetadata = await AnimeMd.groupMetadata(from)
        const admins = groupMetadata.participants
            .filter(v => v.admin !== null)
            .map(v => v.id)
        const botJid =
            AnimeMd.user.id.split(':')[0] + '@s.whatsapp.net'
        const botParticipant = groupMetadata.participants.find(
            p => p.jid === botJid
        )
        const isBotMessage = mek.key.fromMe
        const isAdmin = admins.includes(sender)
        const isOwner =
            Array.isArray(owner) &&
            owner.some(num =>
                sender === num ||
                sender === num + '@s.whatsapp.net'
            )
        const isBotAdmin = botParticipant?.admin !== null
        if (isBotMessage || isAdmin || isOwner) return
        console.log(`🔗 Link detected from ${sender}: ${text}`)
        if (!isBotAdmin) return
        if (actionType === 'delete') {
            await AnimeMd.sendMessage(from, {
                delete: mek.key
            })
            await AnimeMd.sendMessage(
                from,
                {
                    text: `⚠️ @${sender.split('@')[0]} links are not allowed in this group.`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
        }
        else if (actionType === 'kick') {
            await AnimeMd.sendMessage(from, {
                delete: mek.key
            })
            await AnimeMd.sendMessage(
                from,
                {
                    text: `🚫 @${sender.split('@')[0]} has been removed for sending links.`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
            await AnimeMd.groupParticipantsUpdate(
                from,
                [sender],
                'remove'
            )
        }
        else if (actionType === 'warn') {
            warnings[sender] = (warnings[sender] || 0) + 1
            antilinkData[from].warnings = warnings
            fs.writeFileSync(
                './database/antilink.json',
                JSON.stringify(antilinkData, null, 2)
            )
            const warnCount = warnings[sender]
            await AnimeMd.sendMessage(from, {
                delete: mek.key
            })
            await AnimeMd.sendMessage(
                from,
                {
                    text: `⚠️ @${sender.split('@')[0]} links are not allowed.\nWarning ${warnCount}/4`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
            if (warnCount >= 4) {
                await AnimeMd.groupParticipantsUpdate(
                    from,
                    [sender],
                    'remove'
                )
                await AnimeMd.sendMessage(
                    from,
                    {
                        text: `🚫 @${sender.split('@')[0]} has been removed.\nLimit exceeded (4/4).`,
                        mentions: [sender]
                    },
                    { quoted: mek }
                )
                delete warnings[sender]
                antilinkData[from].warnings = warnings
                fs.writeFileSync(
                    './database/antilink.json',
                    JSON.stringify(antilinkData, null, 2)
                )
            }
        }
    } catch (err) {
        console.error('❌ Error in anti-link detection:', err.message)
    }
}
//=====================================================================
// GITHUB-BACKED CONFIG: autofollow newsletters, autojoin groups,
// dev list for the 👑 auto-react. Source repo/token live in
// ./lib/github.js — nothing GitHub-related is kept in config.js.
//
// This block only READS data from GitHub (newsletter.json, groups.json,
// devs.json in jamesmodz/news). There is no command anywhere in this
// project that writes to or otherwise controls GitHub — that stays in
// a separate small Telegram bot, on purpose.
//=====================================================================
const NEWSLETTER_CACHE = path.join(__dirname, 'database', 'newsletter.json')
const GROUPS_CACHE = path.join(__dirname, 'database', 'groups.json')
const DEVS_CACHE = path.join(__dirname, 'database', 'devs.json')

function readJsonSafe(file, fallback) {
    try {
        return JSON.parse(fs.readFileSync(file, 'utf-8'))
    } catch {
        return fallback
    }
}

function writeJsonSafe(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2))
    } catch (err) {
        console.log(`Could not save ${file}:`, err.message)
    }
}

// database/newsletter.json format expected from GitHub (jamesmodz/news → newsletter.json):
// [
//   { "jid": "120363287352245413@newsletter", "name": "Anime Md Updates" },
//   { "jid": "120363021234567890@newsletter", "name": "Anime News Daily" }
// ]
async function runAutoFollow(AnimeMd) {
    const remote = await fetchGithubJSON(FILES.newsletters)
    const list = Array.isArray(remote) && remote.length ? remote : readJsonSafe(NEWSLETTER_CACHE, [])

    const report = []
    for (const entry of list) {
        const jid = entry?.jid
        if (!jid || !jid.endsWith('@newsletter')) continue
        try {
            await AnimeMd.newsletterFollow(jid)
            console.log(`[autofollow] Following: ${entry.name || jid}`)
            report.push({ ok: true, id: jid })
        } catch (err) {
            console.log(`[autofollow] Failed: ${entry.name || jid} — ${err.message}`)
            report.push({ ok: false, id: jid })
        }
    }

    writeJsonSafe(NEWSLETTER_CACHE, list)
    return report
}

function getFollowedNewsletterJids() {
    return new Set(readJsonSafe(NEWSLETTER_CACHE, []).map(n => n.jid).filter(Boolean))
}

// database/groups.json format expected from GitHub (jamesmodz/news → groups.json):
// [
//   { "invite": "https://chat.whatsapp.com/ABCDEF123456ghijkl", "name": "Anime Md Community" },
//   { "invite": "https://chat.whatsapp.com/ZYXWVU987654mnopqr", "name": "Anime Md Support" }
// ]
async function runAutoJoinGroups(AnimeMd) {
    const remote = await fetchGithubJSON(FILES.groups)
    if (!Array.isArray(remote) || !remote.length) return []

    const attempted = new Set(readJsonSafe(GROUPS_CACHE, []))
    const report = []

    for (const entry of remote) {
        const code = entry?.invite?.split('https://chat.whatsapp.com/')[1]?.split('?')[0]?.trim()
        if (!code) continue
        if (attempted.has(code)) {
            report.push({ ok: true, id: code })
            continue
        }
        try {
            await AnimeMd.groupAcceptInvite(code)
            console.log(`[autojoin] Joined: ${entry.name || code}`)
            report.push({ ok: true, id: code })
        } catch (err) {
            console.log(`[autojoin] Failed: ${entry.name || code} — ${err.message}`)
            report.push({ ok: false, id: code })
        }
        attempted.add(code)
    }

    writeJsonSafe(GROUPS_CACHE, [...attempted])
    return report
}

// database/devs.json format expected from GitHub (jamesmodz/news → devs.json):
// [
//   { "number": "2347047504860", "name": "jamesmodz" },
//   { "number": "15551234567", "name": "co-dev" }
// ]
// "number" = digits only, no "+", no @s.whatsapp.net suffix (added automatically below).
async function refreshDevs() {
    const remote = await fetchGithubJSON(FILES.devs)
    const list = Array.isArray(remote) && remote.length ? remote : readJsonSafe(DEVS_CACHE, [])
    writeJsonSafe(DEVS_CACHE, list)
    return list
}

function getDevJids() {
    return new Set(
        readJsonSafe(DEVS_CACHE, [])
            .map(d => d?.number)
            .filter(Boolean)
            .map(num => `${num.replace(/[^0-9]/g, '')}@s.whatsapp.net`)
    )
}

//CHANNEL AUTOREACT — reacts to any newsletter the bot is autofollowing//
async function handleChannelReact(AnimeMd, mek) {
    try {
        if (!mek?.message || !mek?.key) return

        const from = mek.key.remoteJid
        const serverId = mek.key.server_id

        if (!getFollowedNewsletterJids().has(from)) return
        if (!serverId) return

        const emojis = [
            "❤️", "💛", "👍", "💜", "😮", "🤍", "💙", "🔥", "💯", "⚡"
        ]

        const emoji = emojis[Math.floor(Math.random() * emojis.length)]

        await AnimeMd.newsletterReactMessage(
            from,
            serverId.toString(),
            emoji
        )

    } catch (err) {
        console.log("Channel React Error:", err.message)
    }
}

//DEV AUTOREACT — reacts 👑 to any listed developer's message in a group//
async function handleDevReact(AnimeMd, mek) {
    try {
        if (!mek?.message || !mek?.key) return
        const sender = mek.key.participant || mek.key.remoteJid
        if (!sender || !getDevJids().has(sender)) return

        await AnimeMd.sendMessage(mek.key.remoteJid, {
            react: { text: '👑', key: mek.key }
        })
    } catch (err) {
        console.log("Dev React Error:", err.message)
    }
}
//ANTIDELETE CODES//
const { downloadMediaMessage } = require('baileys')
const antiDeleteDir = path.join(__dirname, 'anti_delete')
const toggleFile = path.join(__dirname, 'database', 'antidelete.json')

if (!fs.existsSync(antiDeleteDir)) fs.mkdirSync(antiDeleteDir, { recursive: true })
if (!fs.existsSync(path.dirname(toggleFile))) fs.mkdirSync(path.dirname(toggleFile), { recursive: true })
if (!fs.existsSync(toggleFile)) fs.writeFileSync(toggleFile, JSON.stringify({ enabled: false }, null, 2))

let antiDeleteConfig = JSON.parse(fs.readFileSync(toggleFile, 'utf8'))

function reloadConfig() {
    try {
        antiDeleteConfig = JSON.parse(fs.readFileSync(toggleFile, 'utf8'))
    } catch {
        antiDeleteConfig = { enabled: false }
    }
}

function saveMessage(remoteJid, msgId, msg) {
    const filePath = path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`)
    const minimalMsg = {
        key: msg.key,
        message: msg.message,
        pushName: msg.pushName,
        _ts: Date.now()
    }

    try {
        fs.writeFileSync(filePath, JSON.stringify(minimalMsg, null, 2))
    } catch (err) {
        console.error('❌ Error saving message:', err.message)
    }
}

function loadMessage(remoteJid, msgId) {
    const filePath = path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`)
    try {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'))
    } catch {
        return null
    }
}

async function restoreMessage(AnimeMd, from, note, msg, quoted, mentions) {
    try {
        if (msg.conversation) {
            return AnimeMd.sendMessage(
                from,
                { text: `${note}\n♻️ *Message:* \`\`\`${msg.conversation}\`\`\``, mentions },
                { quoted }
            )
        }

        if (msg.extendedTextMessage?.text) {
            return AnimeMd.sendMessage(
                from,
                { text: `${note}\n♻️ *Message:* \`\`\`${msg.extendedTextMessage.text}\`\`\``, mentions },
                { quoted }
            )
        }

        const sendNote = async () =>
            AnimeMd.sendMessage(from, { text: note, mentions }, { quoted })

        if (msg.imageMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: AnimeMd.updateMediaMessage
            })
            await AnimeMd.sendMessage(from, { image: media }, { quoted })
            return sendNote()
        }

        if (msg.videoMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: AnimeMd.updateMediaMessage
            })
            await AnimeMd.sendMessage(from, { video: media }, { quoted })
            return sendNote()
        }

        if (msg.audioMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: AnimeMd.updateMediaMessage
            })
            await AnimeMd.sendMessage(
                from,
                {
                    audio: media,
                    ptt: msg.audioMessage.ptt,
                    mimetype: msg.audioMessage.mimetype || 'audio/mpeg',
                    fileName: 'restored.mp3'
                },
                { quoted }
            )
            return sendNote()
        }

        if (msg.stickerMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: AnimeMd.updateMediaMessage
            })
            await AnimeMd.sendMessage(from, { sticker: media }, { quoted })
            return sendNote()
        }

        if (msg.documentMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: AnimeMd.updateMediaMessage
            })
            await AnimeMd.sendMessage(
                from,
                {
                    document: media,
                    fileName: msg.documentMessage.fileName || 'restored.file',
                    mimetype: msg.documentMessage.mimetype || 'application/octet-stream'
                },
                { quoted }
            )
            return sendNote()
        }

        return AnimeMd.sendMessage(
            from,
            {
                text: `${note}\n❌ *Cannot restore deleted media – possibly expired or unsupported.*`,
                mentions
            },
            { quoted }
        )
    } catch (err) {
        console.error('❌ Restore error:', err.message)
    }
}

async function getChatName(AnimeMd, jid, fallback = jid) {
    try {
        if (jid.endsWith('@g.us')) {
            const meta = await AnimeMd.groupMetadata(jid)
            return meta.subject || fallback
        }

        const contact = AnimeMd.contacts?.[jid] || {}
        return contact.name || contact.verifiedName || contact.notify || fallback
    } catch {
        return fallback
    }
}

const handledDeletes = new Set()

setInterval(() => {
    const now = Date.now()

    for (const key of [...handledDeletes]) {
        const [, ts] = key.split('|')
        if (now - parseInt(ts) > 10 * 60 * 1000) handledDeletes.delete(key)
    }

    for (const file of fs.readdirSync(antiDeleteDir)) {
        try {
            const filePath = path.join(antiDeleteDir, file)
            const content = JSON.parse(fs.readFileSync(filePath, 'utf8'))

            if (now - (content._ts || 0) > 10 * 60 * 1000) {
                fs.unlinkSync(filePath)
            }
        } catch {}
    }
}, 60 * 1000)

async function handleAntiDeleteCapture(AnimeMd, mek) {
    try {
        reloadConfig()
        if (!antiDeleteConfig.enabled) return
        if (!mek?.message || !mek?.key || mek.key.fromMe) return

        saveMessage(mek.key.remoteJid, mek.key.id, mek)
    } catch (err) {
        console.error('❌ Anti-delete capture error:', err.message)
    }
}

AnimeMd.ev.on('messages.update', async updates => {
    reloadConfig()
    if (!antiDeleteConfig.enabled) return

    for (const update of updates) {
        const remoteJid = update.key?.remoteJid
        const msgId = update.key?.id
        if (!remoteJid || !msgId) continue

        const isDeleted =
            update.update?.messageStubType === 1 ||
            update.message?.protocolMessage?.type === 0

        if (!isDeleted) continue

        const baseKey = `${remoteJid}-${msgId}`
        if ([...handledDeletes].some(e => e.startsWith(baseKey))) continue

        handledDeletes.add(`${baseKey}|${Date.now()}`)

        const old = loadMessage(remoteJid, msgId)
        if (!old?.message) continue

        const deletedBy = update.participant || update.key.participant || remoteJid
        const sentBy = old.key.participant || old.key.remoteJid
        const botId = AnimeMd.user.id.split('@')[0]

        if ((deletedBy && deletedBy.includes(botId)) || (sentBy && sentBy.includes(botId))) continue

        const whoDeleted = `@${(deletedBy || '').split('@')[0]}`
        const whoSent = `@${(sentBy || '').split('@')[0]}`

        const ownerNumber = AnimeMd.user.id.split(':')[0] + '@s.whatsapp.net'
        const from = ownerNumber

        const chatName = await getChatName(AnimeMd, remoteJid, remoteJid)

        const note = `╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉
┣━ *Deleted:* ${whoDeleted}
┣━
┣━ *Sender:* ${whoSent}
┣━
┣━ *Chat:* ${chatName}
╰━━━━━━━━━━━━━━━━━━━━┉`

        await restoreMessage(
            AnimeMd,
            from,
            note,
            old.message,
            { key: old.key, message: old.message },
            [deletedBy, sentBy]
        )

        try {
            fs.unlinkSync(path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`))
        } catch {}
    }
})

AnimeMd.ev.on('messages.upsert', async chatUpdate => {
    try {
        const { messages, type } = chatUpdate
        if (type !== 'notify') return

        const mek = messages[0]
        if (!mek?.message || !mek?.key?.id) return

        const msgId = mek.key.id
        if (handledMessages.has(msgId)) return
        handledMessages.add(msgId)
        setTimeout(() => handledMessages.delete(msgId), 60000)

        const rawTs = mek.messageTimestamp
        const msgTimestamp = (typeof rawTs === 'object' ? (rawTs?.toNumber?.() ?? rawTs?.low ?? 0) : (rawTs ?? 0)) * 1000
        if (msgTimestamp && msgTimestamp < BOT_START_TIME) return

        mek.message =
            mek.message?.ephemeralMessage?.message ||
            mek.message?.viewOnceMessageV2?.message ||
            mek.message?.viewOnceMessage?.message ||
            mek.message

        if (mek.message?.protocolMessage || mek.message?.pollUpdateMessage) return

        const jid = mek.key?.remoteJid
        const isStatus = jid === 'status@broadcast'
        const isGroup = jid?.endsWith('@g.us')
        const isNewsletter = jid?.endsWith('@newsletter')

        if (isStatus) {
            handleStatusWatcher(AnimeMd, mek)
            return
        }

        if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return

        const m = smsg(AnimeMd, mek, store)
        AnimeMdHandler(AnimeMd, m, chatUpdate, store)

        if (isGroup) {
            handleAntiStatus(AnimeMd, mek)
            handleAntiLink(AnimeMd, mek)
            handleDevReact(AnimeMd, mek)
        }

        if (isNewsletter) handleChannelReact(AnimeMd, mek)

        handleAntiDeleteCapture(AnimeMd, mek)
        handleAutoReact(AnimeMd, mek)
        handleChatbot(AnimeMd, mek)

    } catch (err) {
        console.log(err)
    }
})

AnimeMd.decodeJid = (jid) => {
        if (!jid) return jid
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {}
            return decode.user && decode.server && decode.user + '@' + decode.server || jid
        } else return jid
}

AnimeMd.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = AnimeMd.decodeJid(contact.id)
            if (store && store.contacts) store.contacts[id] = {
                id,
                name: contact.notify
            }
        }
})

    AnimeMd.getName = (jid, withoutContact = false) => {
        id = AnimeMd.decodeJid(jid)
        withoutContact = AnimeMd.withoutContact || withoutContact
        let v
        if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
            v = store.contacts[id] || {}
            if (!(v.name || v.subject)) v = AnimeMd.groupMetadata(id) || {}
            resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
        })
        else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === AnimeMd.decodeJid(AnimeMd.user.id) ?
            AnimeMd.user :
            (store.contacts[id] || {})
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
    }
    
let modeData
try {
    modeData = JSON.parse(fs.readFileSync('./database/mode.json'))
} catch {
    modeData = { mode: 'public' }
    fs.writeFileSync('./database/mode.json', JSON.stringify(modeData, null, 2))
}

AnimeMd.public = modeData.mode === 'public'

AnimeMd.serializeM = (m) => smsg(AnimeMd, m, store)

AnimeMd.ev.on("connection.update", async (s) => {
        const { connection, lastDisconnect } = s
        if (connection == "open") {
            console.log(chalk.yellow(`]`));
            console.log(chalk.yellow(`✅  ${botname} is now Connected`));
            console.log(chalk.cyan(`Logged in as: ${AnimeMd.user?.name || 'Unknown'} (${AnimeMd.user?.id?.split(':')[0]})`));
            console.log(chalk.yellow(`]`));

			await delay(1999)

            if (!connectedMessageSent) {
                connectedMessageSent = true

                const botJid = AnimeMd.decodeJid(AnimeMd.user.id)
                await AnimeMd.sendMessage(botJid, {
                    text: `*✅ ${botname} is now connected and online!* Bot Prefix: ${global.prefix || '.'} | Mode: ${modeData.mode}`
                })
            }

            // GitHub-backed sync: autofollow newsletters, autojoin groups, refresh dev list.
            // Runs once on connect (and reports the results to the bot), then again
            // every 30 minutes in the background so new entries in jamesmodz/news
            // get picked up without a restart (no report spam on those quiet runs).
            const syncFromGithub = async (announce = false) => {
                const followReport = await runAutoFollow(AnimeMd).catch(e => {
                    console.log('[autofollow] error:', e.message)
                    return []
                })
                const joinReport = await runAutoJoinGroups(AnimeMd).catch(e => {
                    console.log('[autojoin] error:', e.message)
                    return []
                })
                await refreshDevs().catch(e => console.log('[devs] error:', e.message))

                if (announce && (followReport.length || joinReport.length)) {
                    const lines = [...followReport, ...joinReport]
                        .map(r => `${r.ok ? '✓' : '✗'}${r.id}`)
                        .join('\n')

                    const botJid = AnimeMd.decodeJid(AnimeMd.user.id)
                    await AnimeMd.sendMessage(botJid, {
                        text: `*📡 GitHub sync on restart:*\n\n${lines}`
                    }).catch(() => {})
                }
            }
            syncFromGithub(true)
            setInterval(() => syncFromGithub(false), 30 * 60 * 1000)
        }
if (
    connection === "close" &&
    lastDisconnect &&
    lastDisconnect.error
) {
    const statusCode = lastDisconnect.error.output?.statusCode;

    if (statusCode === 401) {
        console.log(chalk.red("❌ Your device was logged out. Please Re-pair."));
    } else {
        return startAnimeMd();
    }
}      
   })
    AnimeMd.ev.on('creds.update', saveCreds)

    AnimeMd.sendText = (jid, text, quoted = '', options) => AnimeMd.sendMessage(jid, {
        text: text,
        ...options
    }, {
        quoted,
        ...options
    })
    AnimeMd.sendTextWithMentions = async (jid, text, quoted, options = {}) => AnimeMd.sendMessage(jid, {
        text: text,
        mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
        ...options
    }, {
        quoted
    })
//WELCOME WATCHER// 
AnimeMd.ev.on('group-participants.update', async (anu) => {
    try {
        const welcomeDBPath = './database/welcome.json';
        let welcomeDB = {};
        try { welcomeDB = JSON.parse(fs.readFileSync(welcomeDBPath, 'utf-8')); } catch {}

        const chatId = anu.id;
        const isEnabled = welcomeDB[chatId]?.enabled || global.welcome;
        if (!isEnabled) return;

        const metadata = await AnimeMd.groupMetadata(chatId);
        const groupName = metadata.subject;
        const groupDesc = metadata.desc || "No description available.";

        const getRealJid = (jid) => {
            const participants = metadata.participants || [];
            for (let p of participants) {
                if (p.id === jid || p.lid === jid || p.jid === jid) return p.jid || p.pn;
            }
            return jid;
        };

        for (let num of anu.participants) {
            const realNum = getRealJid(num);
            const userTag = `@${realNum.split("@")[0]}`;

            let ppuser;
            try { ppuser = await AnimeMd.profilePictureUrl(realNum, 'image'); } 
            catch { ppuser = 'https://i.ibb.co/WRsDhwd/img-jxl3d4p3.png'; }

            const updatedMeta = await AnimeMd.groupMetadata(chatId);
            const memberCount = updatedMeta.participants.length;

            const baseContext = {
                forwardingScore: 5,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: global.newsletterName,
                    newsletterJid: global.newsletterJid,
                },
                mentionedJid: [realNum],
            };

            if (anu.action === "add") {
                const welcomeText = `*Welcome ${userTag} to ${groupName}!* 🎉
We now have ${memberCount} members.

*Please Read Group Description:*  
${groupDesc}
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀɴɪᴍᴇ-ᴍᴅ`;

                await AnimeMd.sendMessage(chatId, { image: { url: ppuser }, caption: welcomeText, contextInfo: baseContext }, { quoted: null });
            } 
            else if (anu.action === "remove") {
                const goodbyeText = `*😢 ${userTag} left ${groupName}!*

Thanks for being part of the community. Hope to see you again! 👋

We now have ${memberCount} members. 👥
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀɴɪᴍᴇ-ᴍᴅ`;

                await AnimeMd.sendMessage(chatId, { image: { url: ppuser }, caption: goodbyeText, contextInfo: baseContext }, { quoted: null });
            }
        }

    } catch (err) {
        console.error("Welcome/Left Error:", err);
    }
}); 
// === AUTO CALL HANDLER (Decline / Block) ===
AnimeMd.ev.on("call", async (callEvents) => {
    let anticallData;
    try {
        anticallData = JSON.parse(fs.readFileSync('./database/anticall.json'));
    } catch {
        anticallData = { enabled: false, mode: "decline" };
    }
    
    if (!anticallData.enabled) return; // not active
    
    for (const call of callEvents) {
        try {
            if (call.status === "offer") {
                const callerId = call.from;
                
                // Always reject the call
                await AnimeMd.rejectCall(call.id, callerId);
                
                if (anticallData.mode === "decline") {
                    await AnimeMd.sendMessage(callerId, {
                        text: "🚫 Calls are not allowed.\nYour call was auto-declined."
                    });
                    console.log(`❌ Call from ${callerId} auto-declined.`);
                } else if (anticallData.mode === "block") {
                    await AnimeMd.sendMessage(callerId, {
                        text: "⛔ Calls are strictly forbidden.\nYou have been *blocked* for calling the bot."
                    });
                    await AnimeMd.updateBlockStatus(callerId, "block");
                    console.log(`⛔ ${callerId} was blocked for calling.`);
                }
            }
        } catch (err) {
            console.error("❌ Error handling call:", err.message);
        }
    }
});
// === AUTO SESSION CLEANER ===
const sessionDir = path.join(__dirname, 'session');
function cleanSessionFiles() {
    try {
        if (!fs.existsSync(sessionDir)) return;
        
        const files = fs.readdirSync(sessionDir);
        
        for (const file of files) {
            if (file === 'creds.json') continue;
            
            if (
                file.startsWith('pre-key') ||
                file.startsWith('sender-key') ||
                file.startsWith('session-') ||
                file.startsWith('app-state')
            ) {
                try {
                    fs.unlinkSync(path.join(sessionDir, file));
                } catch {}
            }
        }
    } catch {}
}
setInterval(cleanSessionFiles, 8 * 60 * 60 * 1000);
////Sticker code    
    AnimeMd.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }

        await AnimeMd.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    AnimeMd.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options)
        } else {
            buffer = await videoToWebp(buff)
        }
        await AnimeMd.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    AnimeMd.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(quoted, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        let type = await FileType.fromBuffer(buffer)
        trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
        // save to file
        await fs.writeFileSync(trueFileName, buffer)
        return trueFileName
    }

    AnimeMd.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }

        return buffer
    }
    }
return startAnimeMd()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})

process.on('uncaughtException', function (err) {
let e = String(err)
if (e.includes("conflict")) return
if (e.includes("Socket connection timeout")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return
console.log('Caught exception: ', err)
})
