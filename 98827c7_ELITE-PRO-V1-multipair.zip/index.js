const { spawn } = require("child_process");
if (process.argv[2] !== "--child") {
    
    function launch() {
        let p = spawn("node", ["index.js", "--child"], {
            stdio: ["inherit", "inherit", "inherit", "ipc"]
        });
        
        p.on("message", (msg) => {
            if (msg === "reset") {
                p.kill();
                launch();
            }
        });
        
        p.on("exit", (code) => {
            if (code === 0 || code === 1) launch();
        });
    }
    launch();
    return;
}
const path = require('path');
const fs = require('fs');
require('./config')
if (!fs.existsSync(__dirname + '/session/creds.json') && global.sessionid) {
    try {
        const sessionData = JSON.parse(global.sessionid);
        fs.mkdirSync(__dirname + '/session', { recursive: true });
        fs.writeFileSync(__dirname + '/session/creds.json', JSON.stringify(sessionData, null, 2));
    } catch (err) {
    }
}
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const chalk = require('chalk')
const FileType = require('file-type')
const axios = require('axios')
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, sleep, reSize, getGroupAdmins } = require('./lib/myfunc')
const { default: EliteProTechConnect, delay, PHONENUMBER_MCC, makeCacheableSignalKeyStore, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, proto } = require("baileys")
const NodeCache = require("node-cache")
const Pino = require("pino")
const readline = require("readline")
const { parsePhoneNumber } = require("libphonenumber-js")
const makeWASocket = require("baileys").default
const EliteProHandler = require("./ElitePro")
const setupConsoleFilters = require('./lib/filter')
const http = require('http')

const { Telegraf, Markup } = require('telegraf')
const { startWebsitePairingLoop, registerWASocket } = require('./helper-varnox-neon')
const net = require('node:net')
const { startVarnoxBotLoop } = require('./helper-varnox-bot')
const { query, hasDatabase, getWASocket } = require('./helper-varnox-neon')
const pairing = require('./helper/pairing')
setupConsoleFilters()
const PORT = process.env.PORT || 3000;
const INDEX_PATH = path.join(__dirname, 'lib', 'index.html');
http.createServer((req, res) => {
    fs.readFile(INDEX_PATH, (err, data) => {
        if (err) {
            res.writeHead(404);
            return res.end('Not found');
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
    });
}).listen(PORT, "0.0.0.0", () => {});

function createStore() {
    return {
        messages: {},
        contacts: {},
        chats: {},
        groupMetadata: async (jid) => {
            return {}
        },
        bind: function(ev) {
            ev.on('messages.upsert', ({ messages }) => {
                messages.forEach(msg => {
                    if (msg.key && msg.key.remoteJid) {
                        this.messages[msg.key.remoteJid] = this.messages[msg.key.remoteJid] || {}
                        this.messages[msg.key.remoteJid][msg.key.id] = msg
                    }
                })
            })
            
            ev.on('contacts.update', (contacts) => {
                contacts.forEach(contact => {
                    if (contact.id) {
                        this.contacts[contact.id] = contact
                    }
                })
            })
            
            ev.on('chats.set', (chats) => {
                this.chats = chats
            })
        },
        loadMessage: async function (jid, id) {
        return this.messages[jid]?.[id] || null
        }
    }
}

let owner = JSON.parse(fs.readFileSync('./database/owner.json'))

// ── Pairing layer configuration ───────────────────────────────
const TELEGRAM_TOKEN    = process.env.TELEGRAM_TOKEN || ''
const OWNER_TELEGRAM_ID = process.env.OWNER_TELEGRAM_ID || ''
let mainBot = null

async function startSession(sessionId, opts = {}) {
let { version, isLatest } = await fetchLatestBaileysVersion()
pairing.ensureSessionDir(sessionId)
const {  state, saveCreds } = await useMultiFileAuthState(pairing.sessionDir(sessionId))
const store = createStore()
let connectedMessageSent = false
const __timers = []
const __setInterval = (fn, ms) => { const t = setInterval(fn, ms); __timers.push(t); return t }

    const msgRetryCounterCache = new NodeCache()
    const groupMetadataCache = new NodeCache({ stdTTL: 5 * 60, useClones: false })
    const handledMessages = new Set()
    const BOT_START_TIME = Date.now()
    const EliteProTech = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false, 
        browser: [ "Ubuntu", "Chrome", "20.0.04" ],
        auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" }).child({ level: "fatal" })),
      },
	  fireInitQueries: false,
      markOnlineOnConnect: false, 
      generateHighQualityLinkPreview: true, 
      syncFullHistory: false,
	  shouldSyncHistoryMessage: () => false,
      getMessage: async (key) => {
      const msg = await store.loadMessage(key.remoteJid, key.id)
      return msg?.message || undefined
     },
      msgRetryCounterCache,
      cachedGroupMetadata: async (jid) => groupMetadataCache.get(jid),
      defaultQueryTimeoutMs: undefined,
   })
   const _rawGroupMetadata = EliteProTech.groupMetadata.bind(EliteProTech)
   EliteProTech.groupMetadata = async (jid) => {
       const cached = groupMetadataCache.get(jid)
       if (cached) return cached
       try {
           const fresh = await _rawGroupMetadata(jid)
           if (fresh) groupMetadataCache.set(jid, fresh)
           return fresh
       } catch (err) {
           return {}
       }
   }
   EliteProTech.ev.on('groups.update', (updates) => {
       for (const update of updates) {
           if (update?.id) {
               groupMetadataCache.del(update.id)
           }
       }
   })
   EliteProTech.ev.on('group-participants.update', ({ id }) => {
       if (id) groupMetadataCache.del(id)
   })

   registerWASocket(sessionId, EliteProTech)
   pairing.register(sessionId, EliteProTech, {
       phone: opts.pairPhone || null,
       tgChatId: opts.tgChatId || null,
       tgUserId: opts.tgUserId || null,
       source: opts.source || 'telegram',
   })
   EliteProTech.__timers = __timers
   EliteProTech.__sessionId = sessionId
   store.bind(EliteProTech.ev)


   if (opts.pairPhone && !EliteProTech.authState.creds.registered) {
      // NOTE: this baileys fork does NOT export PHONENUMBER_MCC, so the old
      // country-code check is replaced by a simple sanity check. Reading the
      // missing export used to throw and the pairing code was never requested.
      const pairPhoneClean = String(opts.pairPhone).replace(/[^0-9]/g, '')
      if (!pairPhoneClean || pairPhoneClean.length < 7) {
         console.log(chalk.bgBlack(chalk.redBright(`[PAIR ${sessionId}] invalid number: ${pairPhoneClean} (use country code, e.g. 2347047504860)`)))
      }

      const requestCode = async (attempt) => {
         try {
            let code = await EliteProTech.requestPairingCode(pairPhoneClean)
            const pretty = code?.match(/.{1,4}/g)?.join("-") || code
            console.log(chalk.black(chalk.bgGreen(`[PAIR ${sessionId}] Code : `)), chalk.black(chalk.white(pretty)))

            // Website pairing: hand the raw code back so the site can display it.
            if (typeof opts.onPairingCode === 'function') {
               try { await opts.onPairingCode(code, pretty) } catch (e) { console.log('[PAIR] callback failed:', e.message) }
            }

            // Telegram pairing: deliver the code to the chat that asked for it.
            if (opts.tgChatId && mainBot) {
               mainBot.telegram.sendMessage(
                  opts.tgChatId,
                  `🔑 *Pairing code for +${pairPhoneClean}*\n\n\`${pretty}\`\n\nOpen WhatsApp → Linked Devices → Link a device → Link with phone number`,
                  { parse_mode: 'Markdown' }
               ).catch(() => {})
            }
         } catch (e) {
            console.log(chalk.bgBlack(chalk.redBright(`[PAIR ${sessionId}] attempt ${attempt}/3 failed: ${e.message}`)))
            if (attempt < 3) return setTimeout(() => requestCode(attempt + 1), 5000)

            if (typeof EliteProTech.__pairingError === 'function') {
               try { await EliteProTech.__pairingError(`WhatsApp pairing code request failed: ${e.message}`) } catch (_) {}
            }
            if (opts.tgChatId && mainBot) {
               mainBot.telegram.sendMessage(opts.tgChatId, `❌ Pairing failed: ${e.message}`).catch(() => {})
            }
         }
      }

      setTimeout(() => requestCode(1), 3000)
   }

//AUTO STATUS WATCHER//
const processedStatusMessages = new Set()
function resolveStatusTarget(EliteProTech, mek) {
    const candidates = [
        mek?.key?.participantPn,
        mek?.participantPn,
        mek?.key?.participant,
        mek?.participant,
        mek?.sender,
        mek?.key?.remoteJid
    ].filter(Boolean)
    for (let jid of candidates) {
        if (EliteProTech.decodeJid) jid = EliteProTech.decodeJid(jid)
        if (jid?.endsWith('@s.whatsapp.net')) return jid
    }
    for (let jid of candidates) {
        if (EliteProTech.decodeJid) jid = EliteProTech.decodeJid(jid)
        if (jid) return jid
    }
    return null
}

async function handleStatusWatcher(EliteProTech, mek) {
    try {
        if (!mek?.message || !mek?.key || mek.key.fromMe) return
        if (mek.key.remoteJid !== 'status@broadcast') return
        if (!global.autoviewstatus && !global.autolikestatus) return

        const msg = mek.message

        if (msg?.reactionMessage) return
        if (msg?.protocolMessage) return

        const msgId = mek.key.id

        if (processedStatusMessages.has(msgId)) return
        processedStatusMessages.add(msgId)

        setTimeout(() => {
            processedStatusMessages.delete(msgId)
        }, 5 * 60 * 1000)

        const participantJid = resolveStatusTarget(EliteProTech, mek)
        if (!participantJid) return

        const statusKey = {
            remoteJid: 'status@broadcast',
            id: msgId,
            fromMe: false,
            participant: participantJid
        }

        if (global.autoviewstatus) {
            await EliteProTech.readMessages([statusKey])
            console.log(`👀 Viewed status from ${participantJid}`)
        }

        if (!global.autolikestatus) return

        const emojis = [
            '❤️','💸','😇','🍂','💥','💯','🔥','💫','💎','💗',
            '🤍','🖤','👀','🙌','🙆','🚩','🥰','💐','😎','🤎',
            '✅','⚡','🧡','😁','😄','🌸','🕊️','🌷','⛅','🌟',
            '🗿','☠️','💜','💙','🌝','💚'
        ]

        const emoji = emojis[Math.floor(Math.random() * emojis.length)]

        await EliteProTech.sendMessage(
            'status@broadcast',
            {
                react: {
                    text: emoji,
                    key: statusKey
                }
            },
            {
                statusJidList: [participantJid]
            }
        )

        console.log(`✅ Reacted to status from ${participantJid} with ${emoji}`)

    } catch (err) {
        console.error('❌ Status handler error:', err.message)
    }
}
//ANTISTATUS GROUP WATCHER//
async function handleAntiStatus(EliteProTech, mek) {
    try {
        if (!mek?.message || !mek?.key) return

        const from = mek.key.remoteJid
        if (!from || !from.endsWith('@g.us')) return

        const sender = mek.key.participant || from

        if (!mek.message?.groupStatusMentionMessage) return

        let data = {}
        try {
            data = JSON.parse(fs.readFileSync('./database/antistatus.json', 'utf8'))
        } catch {}

        if (!data[from]?.enabled) return

        const metadata = await EliteProTech.groupMetadata(from)
        const admins = metadata.participants
            .filter(v => v.admin !== null)
            .map(v => v.id)

        if (mek.key.fromMe || admins.includes(sender)) return

        const mode = data[from].mode || 'warn'
        const limit = data[from].limit || 3

        if (!data[from].users) data[from].users = {}
        if (!data[from].users[sender]) data[from].users[sender] = 0

        data[from].users[sender] += 1

        await EliteProTech.sendMessage(from, { delete: mek.key })

        if (mode === 'delete') {
            await EliteProTech.sendMessage(from, {
                text: `⚠️ @${sender.split('@')[0]} status mention not allowed.`,
                mentions: [sender]
            }, { quoted: mek })
        }

        if (mode === 'warn') {
            const count = data[from].users[sender]

            await EliteProTech.sendMessage(from, {
                text: `⚠️ Warning ${count}/${limit} @${sender.split('@')[0]}`,
                mentions: [sender]
            }, { quoted: mek })
        }

        if (mode === 'warnkick') {
            const count = data[from].users[sender]

            if (count >= limit) {
                await EliteProTech.groupParticipantsUpdate(from, [sender], 'remove')

                await EliteProTech.sendMessage(from, {
                    text: `🚫 @${sender.split('@')[0]} removed (limit ${limit}).`,
                    mentions: [sender]
                }, { quoted: mek })

                data[from].users[sender] = 0
            } else {
                await EliteProTech.sendMessage(from, {
                    text: `⚠️ Warning ${count}/${limit}`,
                    mentions: [sender]
                }, { quoted: mek })
            }
        }

        if (mode === 'kick') {
            await EliteProTech.groupParticipantsUpdate(from, [sender], 'remove')

            await EliteProTech.sendMessage(from, {
                text: `🚫 @${sender.split('@')[0]} removed for status mention.`,
                mentions: [sender]
            }, { quoted: mek })
        }

        fs.writeFileSync('./database/antistatus.json', JSON.stringify(data, null, 2))

    } catch (err) {
        console.error('AntiStatus Error:', err.message)
    }
}
// AUTOREACT MESSAGE
const emojiFile = path.join(__dirname, './database/autoreact.json')
let emojis = []

function loadEmojis() {
    try {
        const data = fs.readFileSync(emojiFile, 'utf8')
        const parsed = JSON.parse(data)

        if (!Array.isArray(parsed)) throw new Error('Emoji file is not an array')

        emojis = parsed
    } catch (err) {
        emojis = []
        console.error('❌ Failed to load autoreact emojis:', err.message)
    }
}

loadEmojis()

async function handleAutoReact(EliteProTech, mek) {
    try {
        if (!mek?.key || mek.key.fromMe || !mek.key.remoteJid) return
        if (!global.autoreact || emojis.length < 1) return

        const jid = mek.key.remoteJid
        if (jid === 'status@broadcast') return

        const chatType = jid.endsWith('@g.us') ? 'Group' : 'DM'
        const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)]

        await EliteProTech.sendMessage(jid, {
            react: {
                text: randomEmoji,
                key: mek.key
            }
        })

        console.log(`✅ Auto-reacted in ${chatType} (${jid}) with ${randomEmoji}`)

    } catch (err) {
        console.error('❌ Auto-react error:', err.message)
    }
}
//CHATBOT CODES//
const chatbotProcessedMessages=new Set()
async function handleChatbot(EliteProTech,mek){
    try{
        if(!mek?.message||!mek?.key||mek.key.fromMe)return
        const from=mek.key.remoteJid
        if(!from||from==='status@broadcast')return
        const messageKey=`${from}:${mek.key.id}`
        if(chatbotProcessedMessages.has(messageKey))return
        chatbotProcessedMessages.add(messageKey)
        setTimeout(()=>chatbotProcessedMessages.delete(messageKey),60000)
        let chatbotData={global:false,dm:false,group:false,chats:{}}
        try{
            const data=fs.readFileSync('./database/chatbot.json','utf8')
            chatbotData=JSON.parse(data)
        }catch{
            return
        }
        const isGroup=from.endsWith('@g.us')
        const isDM=from.endsWith('@s.whatsapp.net')
        const chatEnabled=chatbotData.chats?.[from]===true
        const typeEnabled=isGroup?chatbotData.group===true:chatbotData.dm===true
        if(!chatbotData.global&&!typeEnabled&&!chatEnabled)return
        const text=mek.message.conversation||mek.message.extendedTextMessage?.text||mek.message.imageMessage?.caption||mek.message.videoMessage?.caption||''
        if(!text.trim())return
        const prefix=global.prefix||'.'
        if(text.trim().startsWith(prefix))return
        const sender=mek.key.participant||from
        global.userChats=global.userChats||{}
        global.userChatTimestamps=global.userChatTimestamps||{}
        global.userChats[sender]=global.userChats[sender]||[]
        global.userChatTimestamps[sender]=Date.now()
        global.userChats[sender].push(`User: ${text}`)
        if(global.userChats[sender].length>15)global.userChats[sender].shift()
        const history=global.userChats[sender].join('\n').slice(-3000)
        const basePrompt=`
You're ElitePro, an intelligent assistant developed by Chinedu (cyrilix-xmd). Respond clearly and naturally. Do not ask, "How can I assist you?"

Owner: Chinedu-md
WhatsApp: https://wa.me/2347047504860
Telegram: https://t.me/eliteprotechs
Website: https://eliteprotech.zone.id/
YouTube: https://www.youtube.com/@eliteprotechs
GitHub: https://eliteproverified.vercel.app/

Services Guide:
- If someone requests a song, reply: ".play [song name]".
- If someone requests a video, reply: ".video [video name]".
- If someone requests an image, reply: ".img [image name]".
- If someone requests menu, reply: ".menu".
- If someone requests a song, reply: ".song [song name]".

Conversation History:
${history}
        `.trim()
        await EliteProTech.sendPresenceUpdate('composing',from)
        await new Promise(resolve=>setTimeout(resolve,1000))
        const apiUrl=`https://eliteprotech-apis.zone.id/deepai?prompt=${encodeURIComponent(text)}`
        const response=await axios.get(apiUrl,{headers:{Accept:'*/*','User-Agent':'Mozilla/5.0'},timeout:30000})
        const botReply=response?.data?.success&&response?.data?.response?response.data.response:'I couldn’t generate a reply at this time. Please try again.'
        await EliteProTech.sendPresenceUpdate('paused',from)
        global.userChats[sender].push(`Bot: ${botReply}`)
        if(global.userChats[sender].length>15)global.userChats[sender].shift()
        await EliteProTech.sendMessage(from,{text:botReply},{quoted:mek})
    }catch(err){
        console.error('❌ Chatbot Error:',err.message)
        try{
            const from=mek?.key?.remoteJid
            if(from)await EliteProTech.sendMessage(from,{text:'❌ An error occurred while processing your message.'},{quoted:mek})
        }catch(fallbackErr){
            console.error('❌ Failed to send error message:',fallbackErr.message)
        }
    }
}
__setInterval(()=>{
    if(!global.userChatTimestamps||!global.userChats)return
    const now=Date.now()
    for(const user in global.userChatTimestamps){
        if(now-global.userChatTimestamps[user]>30*60*1000){
            delete global.userChats[user]
            delete global.userChatTimestamps[user]
            console.log(`🧹 Cleared memory for inactive user: ${user}`)
        }
    }
},10*60*1000)
//ANTILINK DETECT//
async function handleAntiLink(EliteProTech, mek) {
    try {
        if (!mek?.message || !mek?.key) return
        if (mek.message.protocolMessage) return
        const from = mek.key.remoteJid
        if (!from || !from.endsWith('@g.us')) return
        const sender = mek.key.participant || from
        const text =
            mek.message.conversation ||
            mek.message.extendedTextMessage?.text ||
            mek.message.imageMessage?.caption ||
            mek.message.videoMessage?.caption ||
            mek.message.documentMessage?.caption ||
            ''
        if (!isUrl(text)) return
        let antilinkData = {}
        try {
            antilinkData = JSON.parse(
                fs.readFileSync('./database/antilink.json', 'utf8')
            )
        } catch (err) {
            console.error('Error loading antilink.json:', err.message)
            return
        }
        if (!antilinkData[from]?.enabled) return
        const actionType = antilinkData[from].action || 'warn'
        const warnings = antilinkData[from].warnings || {}
        const groupMetadata = await EliteProTech.groupMetadata(from)
        const admins = groupMetadata.participants
            .filter(v => v.admin !== null)
            .map(v => v.id)
        const botJid =
            EliteProTech.user.id.split(':')[0] + '@s.whatsapp.net'
        const botParticipant = groupMetadata.participants.find(
            p => p.jid === botJid
        )
        const isBotMessage = mek.key.fromMe
        const isAdmin = admins.includes(sender)
        const isOwner =
            Array.isArray(owner) &&
            owner.some(num =>
                sender === num ||
                sender === num + '@s.whatsapp.net'
            )
        const isBotAdmin = botParticipant?.admin !== null
        if (isBotMessage || isAdmin || isOwner) return
        console.log(`🔗 Link detected from ${sender}: ${text}`)
        if (!isBotAdmin) return
        if (actionType === 'delete') {
            await EliteProTech.sendMessage(from, {
                delete: mek.key
            })
            await EliteProTech.sendMessage(
                from,
                {
                    text: `⚠️ @${sender.split('@')[0]} links are not allowed in this group.`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
        }
        else if (actionType === 'kick') {
            await EliteProTech.sendMessage(from, {
                delete: mek.key
            })
            await EliteProTech.sendMessage(
                from,
                {
                    text: `🚫 @${sender.split('@')[0]} has been removed for sending links.`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
            await EliteProTech.groupParticipantsUpdate(
                from,
                [sender],
                'remove'
            )
        }
        else if (actionType === 'warn') {
            warnings[sender] = (warnings[sender] || 0) + 1
            antilinkData[from].warnings = warnings
            fs.writeFileSync(
                './database/antilink.json',
                JSON.stringify(antilinkData, null, 2)
            )
            const warnCount = warnings[sender]
            await EliteProTech.sendMessage(from, {
                delete: mek.key
            })
            await EliteProTech.sendMessage(
                from,
                {
                    text: `⚠️ @${sender.split('@')[0]} links are not allowed.\nWarning ${warnCount}/4`,
                    mentions: [sender]
                },
                { quoted: mek }
            )
            if (warnCount >= 4) {
                await EliteProTech.groupParticipantsUpdate(
                    from,
                    [sender],
                    'remove'
                )
                await EliteProTech.sendMessage(
                    from,
                    {
                        text: `🚫 @${sender.split('@')[0]} has been removed.\nLimit exceeded (4/4).`,
                        mentions: [sender]
                    },
                    { quoted: mek }
                )
                delete warnings[sender]
                antilinkData[from].warnings = warnings
                fs.writeFileSync(
                    './database/antilink.json',
                    JSON.stringify(antilinkData, null, 2)
                )
            }
        }
    } catch (err) {
        console.error('❌ Error in anti-link detection:', err.message)
    }
}
//CHANNEL AUTOREACT//
const CHANNEL_ID = "120363287352245413@newsletter"
async function handleChannelReact(EliteProTech, mek) {
    try {
        if (!mek?.message || !mek?.key) return

        const from = mek.key.remoteJid
        const serverId = mek.key.server_id

        if (from !== CHANNEL_ID) return
        if (!serverId) return

        const emojis = [
            "❤️", "💛", "👍", "💜", "😮", "🤍", "💙", "🔥", "💯", "⚡"
        ]

        const emoji = emojis[Math.floor(Math.random() * emojis.length)]

        await EliteProTech.newsletterReactMessage(
            from,
            serverId.toString(),
            emoji
        )

    } catch (err) {
        console.log("Channel React Error:", err.message)
    }
}
//ANTIDELETE CODES//
const { downloadMediaMessage } = require('baileys')
const antiDeleteDir = path.join(__dirname, 'anti_delete')
const toggleFile = path.join(__dirname, 'database', 'antidelete.json')

if (!fs.existsSync(antiDeleteDir)) fs.mkdirSync(antiDeleteDir, { recursive: true })
if (!fs.existsSync(path.dirname(toggleFile))) fs.mkdirSync(path.dirname(toggleFile), { recursive: true })
if (!fs.existsSync(toggleFile)) fs.writeFileSync(toggleFile, JSON.stringify({ enabled: false }, null, 2))

let antiDeleteConfig = JSON.parse(fs.readFileSync(toggleFile, 'utf8'))

function reloadConfig() {
    try {
        antiDeleteConfig = JSON.parse(fs.readFileSync(toggleFile, 'utf8'))
    } catch {
        antiDeleteConfig = { enabled: false }
    }
}

function saveMessage(remoteJid, msgId, msg) {
    const filePath = path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`)
    const minimalMsg = {
        key: msg.key,
        message: msg.message,
        pushName: msg.pushName,
        _ts: Date.now()
    }

    try {
        fs.writeFileSync(filePath, JSON.stringify(minimalMsg, null, 2))
    } catch (err) {
        console.error('❌ Error saving message:', err.message)
    }
}

function loadMessage(remoteJid, msgId) {
    const filePath = path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`)
    try {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'))
    } catch {
        return null
    }
}

async function restoreMessage(EliteProTech, from, note, msg, quoted, mentions) {
    try {
        if (msg.conversation) {
            return EliteProTech.sendMessage(
                from,
                { text: `${note}\n♻️ *Message:* \`\`\`${msg.conversation}\`\`\``, mentions },
                { quoted }
            )
        }

        if (msg.extendedTextMessage?.text) {
            return EliteProTech.sendMessage(
                from,
                { text: `${note}\n♻️ *Message:* \`\`\`${msg.extendedTextMessage.text}\`\`\``, mentions },
                { quoted }
            )
        }

        const sendNote = async () =>
            EliteProTech.sendMessage(from, { text: note, mentions }, { quoted })

        if (msg.imageMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: EliteProTech.updateMediaMessage
            })
            await EliteProTech.sendMessage(from, { image: media }, { quoted })
            return sendNote()
        }

        if (msg.videoMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: EliteProTech.updateMediaMessage
            })
            await EliteProTech.sendMessage(from, { video: media }, { quoted })
            return sendNote()
        }

        if (msg.audioMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: EliteProTech.updateMediaMessage
            })
            await EliteProTech.sendMessage(
                from,
                {
                    audio: media,
                    ptt: msg.audioMessage.ptt,
                    mimetype: msg.audioMessage.mimetype || 'audio/mpeg',
                    fileName: 'restored.mp3'
                },
                { quoted }
            )
            return sendNote()
        }

        if (msg.stickerMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: EliteProTech.updateMediaMessage
            })
            await EliteProTech.sendMessage(from, { sticker: media }, { quoted })
            return sendNote()
        }

        if (msg.documentMessage) {
            const media = await downloadMediaMessage(quoted, 'buffer', {}, {
                reuploadRequest: EliteProTech.updateMediaMessage
            })
            await EliteProTech.sendMessage(
                from,
                {
                    document: media,
                    fileName: msg.documentMessage.fileName || 'restored.file',
                    mimetype: msg.documentMessage.mimetype || 'application/octet-stream'
                },
                { quoted }
            )
            return sendNote()
        }

        return EliteProTech.sendMessage(
            from,
            {
                text: `${note}\n❌ *Cannot restore deleted media – possibly expired or unsupported.*`,
                mentions
            },
            { quoted }
        )
    } catch (err) {
        console.error('❌ Restore error:', err.message)
    }
}

async function getChatName(EliteProTech, jid, fallback = jid) {
    try {
        if (jid.endsWith('@g.us')) {
            const meta = await EliteProTech.groupMetadata(jid)
            return meta.subject || fallback
        }

        const contact = EliteProTech.contacts?.[jid] || {}
        return contact.name || contact.verifiedName || contact.notify || fallback
    } catch {
        return fallback
    }
}

const handledDeletes = new Set()

__setInterval(() => {
    const now = Date.now()

    for (const key of [...handledDeletes]) {
        const [, ts] = key.split('|')
        if (now - parseInt(ts) > 10 * 60 * 1000) handledDeletes.delete(key)
    }

    for (const file of fs.readdirSync(antiDeleteDir)) {
        try {
            const filePath = path.join(antiDeleteDir, file)
            const content = JSON.parse(fs.readFileSync(filePath, 'utf8'))

            if (now - (content._ts || 0) > 10 * 60 * 1000) {
                fs.unlinkSync(filePath)
            }
        } catch {}
    }
}, 60 * 1000)

async function handleAntiDeleteCapture(EliteProTech, mek) {
    try {
        reloadConfig()
        if (!antiDeleteConfig.enabled) return
        if (!mek?.message || !mek?.key || mek.key.fromMe) return

        saveMessage(mek.key.remoteJid, mek.key.id, mek)
    } catch (err) {
        console.error('❌ Anti-delete capture error:', err.message)
    }
}

EliteProTech.ev.on('messages.update', async updates => {
    reloadConfig()
    if (!antiDeleteConfig.enabled) return

    for (const update of updates) {
        const remoteJid = update.key?.remoteJid
        const msgId = update.key?.id
        if (!remoteJid || !msgId) continue

        const isDeleted =
            update.update?.messageStubType === 1 ||
            update.message?.protocolMessage?.type === 0

        if (!isDeleted) continue

        const baseKey = `${remoteJid}-${msgId}`
        if ([...handledDeletes].some(e => e.startsWith(baseKey))) continue

        handledDeletes.add(`${baseKey}|${Date.now()}`)

        const old = loadMessage(remoteJid, msgId)
        if (!old?.message) continue

        const deletedBy = update.participant || update.key.participant || remoteJid
        const sentBy = old.key.participant || old.key.remoteJid
        const botId = EliteProTech.user.id.split('@')[0]

        if ((deletedBy && deletedBy.includes(botId)) || (sentBy && sentBy.includes(botId))) continue

        const whoDeleted = `@${(deletedBy || '').split('@')[0]}`
        const whoSent = `@${(sentBy || '').split('@')[0]}`

        const ownerNumber = EliteProTech.user.id.split(':')[0] + '@s.whatsapp.net'
        const from = ownerNumber

        const chatName = await getChatName(EliteProTech, remoteJid, remoteJid)

        const note = `╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉
┣━ *Deleted:* ${whoDeleted}
┣━
┣━ *Sender:* ${whoSent}
┣━
┣━ *Chat:* ${chatName}
╰━━━━━━━━━━━━━━━━━━━━┉`

        await restoreMessage(
            EliteProTech,
            from,
            note,
            old.message,
            { key: old.key, message: old.message },
            [deletedBy, sentBy]
        )

        try {
            fs.unlinkSync(path.join(antiDeleteDir, `${remoteJid}_${msgId}.json`))
        } catch {}
    }
})

EliteProTech.ev.on('messages.upsert', async chatUpdate => {
    try {
        const { messages, type } = chatUpdate
        if (type !== 'notify') return

        const mek = messages[0]
        if (!mek?.message || !mek?.key?.id) return

        const msgId = mek.key.id
        if (handledMessages.has(msgId)) return
        handledMessages.add(msgId)
        setTimeout(() => handledMessages.delete(msgId), 60000)

        const rawTs = mek.messageTimestamp
        const msgTimestamp = (typeof rawTs === 'object' ? (rawTs?.toNumber?.() ?? rawTs?.low ?? 0) : (rawTs ?? 0)) * 1000
        if (msgTimestamp && msgTimestamp < BOT_START_TIME) return

        mek.message =
            mek.message?.ephemeralMessage?.message ||
            mek.message?.viewOnceMessageV2?.message ||
            mek.message?.viewOnceMessage?.message ||
            mek.message

        if (mek.message?.protocolMessage || mek.message?.pollUpdateMessage) return

        const jid = mek.key?.remoteJid
        const isStatus = jid === 'status@broadcast'
        const isGroup = jid?.endsWith('@g.us')
        const isNewsletter = jid?.endsWith('@newsletter')

        if (isStatus) {
            handleStatusWatcher(EliteProTech, mek)
            return
        }

        if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return

        const m = smsg(EliteProTech, mek, store)
        EliteProHandler(EliteProTech, m, chatUpdate, store)

        if (isGroup) {
            handleAntiStatus(EliteProTech, mek)
            handleAntiLink(EliteProTech, mek)
        }

        if (isNewsletter) handleChannelReact(EliteProTech, mek)

        handleAntiDeleteCapture(EliteProTech, mek)
        handleAutoReact(EliteProTech, mek)
        handleChatbot(EliteProTech, mek)

    } catch (err) {
        console.log(err)
    }
})

EliteProTech.decodeJid = (jid) => {
        if (!jid) return jid
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {}
            return decode.user && decode.server && decode.user + '@' + decode.server || jid
        } else return jid
}

EliteProTech.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = EliteProTech.decodeJid(contact.id)
            if (store && store.contacts) store.contacts[id] = {
                id,
                name: contact.notify
            }
        }
})

    EliteProTech.getName = (jid, withoutContact = false) => {
        id = EliteProTech.decodeJid(jid)
        withoutContact = EliteProTech.withoutContact || withoutContact
        let v
        if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
            v = store.contacts[id] || {}
            if (!(v.name || v.subject)) v = EliteProTech.groupMetadata(id) || {}
            resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
        })
        else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === EliteProTech.decodeJid(EliteProTech.user.id) ?
            EliteProTech.user :
            (store.contacts[id] || {})
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
    }
    
let modeData
try {
    modeData = JSON.parse(fs.readFileSync('./database/mode.json'))
} catch {
    modeData = { mode: 'public' }
    fs.writeFileSync('./database/mode.json', JSON.stringify(modeData, null, 2))
}

EliteProTech.public = modeData.mode === 'public'

EliteProTech.serializeM = (m) => smsg(EliteProTech, m, store)

EliteProTech.ev.on("connection.update", async (s) => {
        const { connection, lastDisconnect } = s
        if (connection == "open") {
            console.log(chalk.yellow(`]`));
            console.log(chalk.yellow(`✅  ${botname} is now Connected`));
            console.log(chalk.cyan(`Logged in as: ${EliteProTech.user?.name || 'Unknown'} (${EliteProTech.user?.id?.split(':')[0]})`));
            console.log(chalk.yellow(`]`));

			await delay(1999)

            if (!connectedMessageSent) {
                connectedMessageSent = true

                const botJid = EliteProTech.decodeJid(EliteProTech.user.id)
                await EliteProTech.sendMessage(botJid, {
                    text: `*✅ ELITE-PRO-V1 is now connected and online!* Bot Prefix: ${global.prefix || '.'} | Mode: ${modeData.mode}\n\n*Join us:* https://t.me/eliteprotechs`
                })
            }
        }
 if (
     connection === "close" &&
     lastDisconnect &&
     lastDisconnect.error
 ) {
     const statusCode = lastDisconnect.error.output?.statusCode;

     /**
      * Say *why*, not just *how*.
      *
      * The status code alone cannot be acted on. This fork reports 408 for every
      * network-layer failure - a reset connection, a DNS miss, a refused host and an idle drop
      * all arrive as 408 - and each has a different fix. The underlying socket error was being
      * thrown away here, so a blocked network looked exactly like a slow one.
      */
     const cause = lastDisconnect.error.message || 'no reason given';
     const socketCode = lastDisconnect.error.data?.code || lastDisconnect.error.data?.message;
     console.log(chalk.red(`[SESSION ${sessionId}] connection closed (${statusCode}) - ${cause}${socketCode ? ` [${socketCode}]` : ''}`));

     // stop this session's background timers before deciding what to do next
     try { (EliteProTech.__timers || []).forEach(t => clearInterval(t)) } catch {}

     if (statusCode === 401 || statusCode === DisconnectReason.loggedOut) {
         console.log(chalk.red(`[SESSION ${sessionId}] device logged out - session removed, re-pair required.`));
         pairing.unregister(sessionId);
         pairing.markDisconnected(sessionId);
         try { pairing.deleteSessionDir(sessionId) } catch {}
         if (opts.tgChatId && mainBot) {
             mainBot.telegram.sendMessage(opts.tgChatId, `🚪 +${opts.pairPhone || sessionId} logged out & removed.\nUse /pair to connect again.`).catch(() => {})
         }
     } else if (!EliteProTech.authState?.creds?.registered) {
         /**
          * A session that has NOT finished pairing is never restarted.
          *
          * Restarting calls startSession again with the same opts, so pairPhone is still set and
          * the code gets requested a second time on a fresh socket - which invalidates the first
          * one. Whoever is watching sees the code change while they are typing it, and WhatsApp
          * sees repeated code requests for a number that never completes, which is the road to
          * the 401 "device logged out" that follows.
          *
          * So a dropped pairing is reported, not retried. Trying again stays the user's call.
          */
         pairing.markDisconnected(sessionId);
         console.log(chalk.yellow(`[SESSION ${sessionId}] pairing was still in progress - not restarting, so the code shown above is now dead.`));
         if (typeof EliteProTech.__pairingError === 'function') {
             try { await EliteProTech.__pairingError(`The WhatsApp connection dropped before pairing finished (${cause}). Please try /pair again.`) } catch (_) {}
         }
     } else {
         // Already paired: reconnect as before. This is a bot going back online, not a code
         // being reissued, so the aggressive retry is safe here.
         pairing.markDisconnected(sessionId);
         setTimeout(() => {
             startSession(sessionId, opts).catch(e => console.log(`[SESSION ${sessionId}] restart failed:`, e.message));
         }, 5000);
     }
 }

   })
    EliteProTech.ev.on('creds.update', saveCreds)

    // ── pairing layer bookkeeping (kept separate from the bot's own handler) ──
    EliteProTech.ev.on('connection.update', async ({ connection }) => {
        try {
            if (connection === 'open') {
                const waNum = String(EliteProTech.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '')
                pairing.markConnected(sessionId, waNum)
                console.log(chalk.green(`[SESSION ${sessionId}] connected +${waNum} (${pairing.activeCount()} live)`))
                if (opts.tgChatId && mainBot && !opts.__connectNotified) {
                    opts.__connectNotified = true
                    mainBot.telegram.sendMessage(opts.tgChatId, `✅ *Connected!*\nNumber: wa.me/${waNum}`, { parse_mode: 'Markdown' }).catch(() => {})
                }
            }
        } catch (_) { /* ignore */ }
    })


    EliteProTech.sendText = (jid, text, quoted = '', options) => EliteProTech.sendMessage(jid, {
        text: text,
        ...options
    }, {
        quoted,
        ...options
    })
    EliteProTech.sendTextWithMentions = async (jid, text, quoted, options = {}) => EliteProTech.sendMessage(jid, {
        text: text,
        mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
        ...options
    }, {
        quoted
    })
//WELCOME WATCHER// 
EliteProTech.ev.on('group-participants.update', async (anu) => {
    try {
        const welcomeDBPath = './database/welcome.json';
        let welcomeDB = {};
        try { welcomeDB = JSON.parse(fs.readFileSync(welcomeDBPath, 'utf-8')); } catch {}

        const chatId = anu.id;
        const isEnabled = welcomeDB[chatId]?.enabled || global.welcome;
        if (!isEnabled) return;

        const metadata = await EliteProTech.groupMetadata(chatId);
        const groupName = metadata.subject;
        const groupDesc = metadata.desc || "No description available.";

        const getRealJid = (jid) => {
            const participants = metadata.participants || [];
            for (let p of participants) {
                if (p.id === jid || p.lid === jid || p.jid === jid) return p.jid || p.pn;
            }
            return jid;
        };

        for (let num of anu.participants) {
            const realNum = getRealJid(num);
            const userTag = `@${realNum.split("@")[0]}`;

            let ppuser;
            try { ppuser = await EliteProTech.profilePictureUrl(realNum, 'image'); } 
            catch { ppuser = 'https://i.ibb.co/WRsDhwd/img-jxl3d4p3.png'; }

            const updatedMeta = await EliteProTech.groupMetadata(chatId);
            const memberCount = updatedMeta.participants.length;

            const baseContext = {
                forwardingScore: 5,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: "ᴇʟɪᴛᴇ-ᴘʀᴏ-ᴛᴇᴄʜ-ꜱᴜᴘᴘᴏʀᴛ",
                    newsletterJid: "120363287352245413@newsletter",
                },
                mentionedJid: [realNum],
            };

            if (anu.action === "add") {
                const welcomeText = `*Welcome ${userTag} to ${groupName}!* 🎉
We now have ${memberCount} members.

*Please Read Group Description:*  
${groupDesc}
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴇʟɪᴛᴇ-ᴘʀᴏ-ᴛᴇᴄʜ`;

                await EliteProTech.sendMessage(chatId, { image: { url: ppuser }, caption: welcomeText, contextInfo: baseContext }, { quoted: null });
            } 
            else if (anu.action === "remove") {
                const goodbyeText = `*😢 ${userTag} left ${groupName}!*

Thanks for being part of the community. Hope to see you again! 👋

We now have ${memberCount} members. 👥
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴇʟɪᴛᴇ-ᴘʀᴏ-ᴛᴇᴄʜ`;

                await EliteProTech.sendMessage(chatId, { image: { url: ppuser }, caption: goodbyeText, contextInfo: baseContext }, { quoted: null });
            }
        }

    } catch (err) {
        console.error("Welcome/Left Error:", err);
    }
}); 
// === AUTO CALL HANDLER (Decline / Block) ===
EliteProTech.ev.on("call", async (callEvents) => {
    let anticallData;
    try {
        anticallData = JSON.parse(fs.readFileSync('./database/anticall.json'));
    } catch {
        anticallData = { enabled: false, mode: "decline" };
    }
    
    if (!anticallData.enabled) return; // not active
    
    for (const call of callEvents) {
        try {
            if (call.status === "offer") {
                const callerId = call.from;
                
                // Always reject the call
                await EliteProTech.rejectCall(call.id, callerId);
                
                if (anticallData.mode === "decline") {
                    await EliteProTech.sendMessage(callerId, {
                        text: "🚫 Calls are not allowed.\nYour call was auto-declined."
                    });
                    console.log(`❌ Call from ${callerId} auto-declined.`);
                } else if (anticallData.mode === "block") {
                    await EliteProTech.sendMessage(callerId, {
                        text: "⛔ Calls are strictly forbidden.\nYou have been *blocked* for calling the bot."
                    });
                    await EliteProTech.updateBlockStatus(callerId, "block");
                    console.log(`⛔ ${callerId} was blocked for calling.`);
                }
            }
        } catch (err) {
            console.error("❌ Error handling call:", err.message);
        }
    }
});
// === AUTO SESSION CLEANER ===
const sessionDir = pairing.sessionDir(sessionId);
function cleanSessionFiles() {
    try {
        if (!fs.existsSync(sessionDir)) return;
        
        const files = fs.readdirSync(sessionDir);
        
        for (const file of files) {
            if (file === 'creds.json') continue;
            
            if (
                file.startsWith('pre-key') ||
                file.startsWith('sender-key') ||
                file.startsWith('session-') ||
                file.startsWith('app-state')
            ) {
                try {
                    fs.unlinkSync(path.join(sessionDir, file));
                } catch {}
            }
        }
    } catch {}
}
__setInterval(cleanSessionFiles, 8 * 60 * 60 * 1000);
////Sticker code    
    EliteProTech.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }

        await EliteProTech.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    EliteProTech.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options)
        } else {
            buffer = await videoToWebp(buff)
        }
        await EliteProTech.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    EliteProTech.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(quoted, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        let type = await FileType.fromBuffer(buffer)
        trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
        // save to file
        await fs.writeFileSync(trueFileName, buffer)
        return trueFileName
    }

    EliteProTech.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }

        return buffer
    }

    // Hand the live socket back to the caller (website bridge, Telegram bot, tooling).
    return EliteProTech
}


process.on('uncaughtException', function (err) {
let e = String(err)
if (e.includes("conflict")) return
if (e.includes("Socket connection timeout")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return
console.log('Caught exception: ', err)
})

// ============================================================
//   TELEGRAM PAIRING BOT
//   /pair  /listpaired  /delpair  /refreshsession
//   Every paired number runs the full ELITE-PRO bot.
// ============================================================

const BTN_PAIR    = '🔗 PAIR NUMBER'
const BTN_LIST    = '📋 MY NUMBERS'
const BTN_REFRESH = '🔄 REFRESH SESSIONS'
const BTN_DELETE  = '🗑️ DELETE NUMBER'

const PAIR_HELP =
  '🔐 *' + (global.botname || 'ELITE-PRO-V1') + ' – Pairing*\n\n' +
  'Pair here or on the website — every paired number runs the full bot.\n\n' +
  '━━━ 📱 *Commands* ━━━\n' +
  '`/pair <number>` – pair a number (example `/pair 2347047504860`)\n' +
  '`/listpaired` – list your paired numbers\n' +
  '`/refreshsession` – restart your sessions\n' +
  '`/delpair <number>` – disconnect & delete a number\n' +
  '`/cancel` – cancel the current step\n\n' +
  '━━━ 🌐 *Website* ━━━\n' +
  'Website pairing requests are picked up automatically — no command needed.'

function pairingKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        [{ text: BTN_PAIR }],
        [{ text: BTN_LIST }, { text: BTN_REFRESH }],
        [{ text: BTN_DELETE }],
      ],
      resize_keyboard: true,
      one_time_keyboard: false,
    },
  }
}

// ── Pair one number (Telegram) ───────────────────────────────
async function pairNumber(ctx, phone, uid) {
  const sessionId = `tg_${uid}_${phone}`;

  const ownerInfo = pairing.ownerOf(sessionId);
  if (ownerInfo && String(ownerInfo.tgUserId) !== String(uid)) {
    return ctx.reply('⛔ That number is already paired by another user.');
  }

  const live = pairing.get(sessionId);
  if (live && live.status === 'connected') {
    return ctx.reply(`✅ +${phone} is already connected.`);
  }

  pairing.addPair(uid, sessionId, phone);

  if (pairing.isLive(sessionId)) {
    await ctx.reply(`♻️ Restarting +${phone}...`);
  } else {
    await ctx.reply(`🔄 Pairing *+${phone}*...`, { parse_mode: 'Markdown' });
  }

  try {
    // startSession requests a code only when the creds are not registered yet,
    // so an already-paired number simply reconnects.
    await startSession(sessionId, {
      pairPhone: phone,
      source: 'telegram',
      tgChatId: ctx.chat.id,
      tgUserId: uid,
    });
  } catch (e) {
    await ctx.reply(`❌ Failed to start pairing: ${e.message}`);
  }
}

// ── Delete one number (Telegram) ─────────────────────────────
async function deletePair(ctx, phone, uid) {
  const sessionId = `tg_${uid}_${phone}`;

  const ownerInfo = pairing.ownerOf(sessionId);
  if (ownerInfo && String(ownerInfo.tgUserId) !== String(uid)) {
    return ctx.reply('⛔ That number is paired by another user.');
  }

  const wasLive = pairing.isLive(sessionId);
  await pairing.stopSession(sessionId);
  pairing.removePair(uid, sessionId);
  const deleted = pairing.deleteSessionDir(sessionId);

  await ctx.reply((wasLive || deleted)
    ? `🗑️ +${phone} disconnected and deleted. Use /pair ${phone} to connect again.`
    : `ℹ️ No session found for +${phone}.`);
}

function setupTelegramBot() {
  if (!TELEGRAM_TOKEN) return null;

  const bot = new Telegraf(TELEGRAM_TOKEN);
  const states = new Map();

  bot.start(async (ctx) => {
    await ctx.reply(PAIR_HELP, { parse_mode: 'Markdown', ...pairingKeyboard() });
    await ctx.reply('Tap below or type /pair 2347047504860 to start:', {
      ...Markup.inlineKeyboard([[Markup.button.callback('📱 Pair a number', 'pair_new')]]),
    }).catch(() => {});
  });

  bot.command('help', async (ctx) => {
    await ctx.reply(PAIR_HELP, { parse_mode: 'Markdown', ...pairingKeyboard() });
  });

  bot.action('pair_new', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    states.set(String(ctx.from.id), 'pair');
    await ctx.reply('📱 Send the number to pair, e.g. `2347047504860`', { parse_mode: 'Markdown' });
  });

  bot.command('pair', async (ctx) => {
    const phone = (ctx.message.text.split(/\s+/)[1] || '').replace(/\D/g, '');
    if (!phone || phone.length < 7) {
      return ctx.reply('Usage: `/pair 2347047504860`', { parse_mode: 'Markdown' });
    }
    await pairNumber(ctx, phone, String(ctx.from.id));
  });

  bot.command('listpaired', async (ctx) => {
    const uid = String(ctx.from.id);
    const pairs = pairing.getUserPairs(uid);
    if (!pairs.length) return ctx.reply('No paired numbers yet. Use /pair 2347047504860');
    const lines = pairs.map((p, i) => {
      const e = pairing.get(p.sessionId);
      const dot = e && e.status === 'connected' ? '🟢' : e ? '🟡' : '🔴';
      return `${i + 1}. +${p.phone || '?'} — ${dot} ${p.sessionId}`;
    }).join('\n');
    await ctx.reply(`📱 *Your numbers (${pairs.length}):*\n\n${lines}`, { parse_mode: 'Markdown' });
  });

  bot.command('delpair', async (ctx) => {
    const phone = (ctx.message.text.split(/\s+/)[1] || '').replace(/\D/g, '');
    if (!phone) return ctx.reply('Usage: /delpair 2347047504860');
    await deletePair(ctx, phone, String(ctx.from.id));
  });

  bot.command('refreshsession', async (ctx) => {
    const uid = String(ctx.from.id);
    const pairs = pairing.getUserPairs(uid);
    if (!pairs.length) return ctx.reply('No paired numbers to refresh.');

    await ctx.reply(`🔄 Restarting ${pairs.length} session(s)...`);
    let done = 0;
    for (const p of pairs) {
      try {
        await pairing.stopSession(p.sessionId);
        await startSession(p.sessionId, { source: 'telegram', tgChatId: ctx.chat.id, tgUserId: uid });
        done++;
      } catch (e) {
        console.log(`[SESSION ${p.sessionId}] refresh failed:`, e.message);
      }
    }
    await ctx.reply(`✅ Restarted ${done}/${pairs.length} session(s).`);
  });

  bot.command('cancel', async (ctx) => {
    states.delete(String(ctx.from.id));
    await ctx.reply('❌ Cancelled.');
  });

  bot.command('status', async (ctx) => {
    if (OWNER_TELEGRAM_ID && String(ctx.from.id) !== String(OWNER_TELEGRAM_ID)) {
      return ctx.reply('⛔ Owner only.');
    }
    const list = pairing.statusList();
    const text = list.length
      ? list.map(s => `${s.status === 'connected' ? '🟢' : '🟡'} ${s.id} (+${s.waNum || '?'}) [${s.source}]`).join('\n')
      : 'No sessions running.';
    await ctx.reply(`🖥 *Live sessions (${list.length}):*\n\n${text}`, { parse_mode: 'Markdown' });
  });

  bot.on('message', async (ctx, next) => {
    const text = ctx.message && ctx.message.text;
    if (!text) return next();
    const uid = String(ctx.from.id);

    if (text === BTN_PAIR) {
      states.set(uid, 'pair');
      return ctx.reply('📱 Send the number to pair, e.g. `2347047504860`', { parse_mode: 'Markdown' });
    }
    if (text === BTN_LIST)    return ctx.telegram.sendMessage(ctx.chat.id, '/listpaired');
    if (text === BTN_REFRESH) return ctx.telegram.sendMessage(ctx.chat.id, '/refreshsession');
    if (text === BTN_DELETE) {
      states.set(uid, 'delpair');
      return ctx.reply('🗑️ Send the number to delete, e.g. `2347047504860`', { parse_mode: 'Markdown' });
    }

    const state = states.get(uid);
    if (state) {
      const phone = text.replace(/\D/g, '');
      if (!phone || phone.length < 7) {
        return ctx.reply('❌ Invalid number. Example: 2347047504860');
      }
      states.delete(uid);
      if (state === 'pair')    return pairNumber(ctx, phone, uid);
      if (state === 'delpair') return deletePair(ctx, phone, uid);
    }

    return next();
  });

  bot.catch((err, ctx) => {
    console.log('[TELEGRAM] error:', err && err.message);
  });

  bot.launch({ dropPendingUpdates: true })
    .then(() => console.log(chalk.green('[TELEGRAM] pairing bot running')))
    .catch(e => console.log(chalk.red('[TELEGRAM] launch failed: ' + e.message)));

  return bot;
}

// ============================================================
//   LAUNCHER – owner session + every saved session + website bridge
// ============================================================

/**
 * Say whether this container can actually reach WhatsApp.
 *
 * A dropped socket arrives as `connection closed (408)`, and 408 covers a reset connection, a
 * DNS failure, a refused host and an idle drop. Inside a container the underlying cause is
 * normally invisible, and the symptom is identical whether the host is blocking WhatsApp or
 * WhatsApp is refusing us - so the bot checks for itself at boot and prints what it found.
 *
 * DNS first, then a real TCP connection: a name that resolves and a port that refuses are
 * different problems, and only the second one is usually the host's doing.
 */
async function probeWhatsApp() {
  const dns = require('node:dns').promises

  for (const [host, port] of [['web.whatsapp.com', 443], ['g.whatsapp.net', 443]]) {
    let address
    try {
      ({ address } = await dns.lookup(host))
    } catch (e) {
      console.log(chalk.red(`[NET] DNS lookup FAILED for ${host}: ${e.code || e.message}`))
      continue
    }

    const outcome = await new Promise((resolve) => {
      const sock = net.connect({ host, port, timeout: 8000 })
      sock.once('connect', () => { sock.destroy(); resolve('ok') })
      sock.once('timeout', () => { sock.destroy(); resolve('timed out after 8s') })
      sock.once('error', (e) => { sock.destroy(); resolve(e.code || e.message) })
    })

    if (outcome === 'ok') console.log(chalk.green(`[NET] ${host}:${port} reachable (${address})`))
    else console.log(chalk.red(`[NET] CANNOT reach ${host}:${port} (${address}) - ${outcome}`))
  }

  // Which protocol version this fork believes it should speak. A fork frozen at an old version
  // handshakes fine and then has its stream closed straight after - one of the things a 408 can
  // mean - so it is worth seeing at boot rather than inferring later.
  try {
    const { version, isLatest } = await fetchLatestBaileysVersion()
    console.log(chalk.cyan(`[NET] WhatsApp web version ${version.join('.')}${isLatest ? ' (latest)' : ' (NOT latest - the fork may be stale)'}`))
  } catch (e) {
    console.log(chalk.red(`[NET] could not fetch the WhatsApp version: ${e.message}`))
  }
}

async function launch() {
  console.log(chalk.cyanBright(`\n[BOOT] ${global.botname || 'ELITE-PRO-V1'} – multi-session pairing build\n`));

  // Before anything else: can this box reach WhatsApp? Every confusing pairing failure starts
  // here, and the answer is one line in the console.
  await probeWhatsApp();

  mainBot = setupTelegramBot();

  // 1) The owner's own session from SESSION_ID / ./session keeps working.
  if (pairing.sessionExists(pairing.LEGACY_ID)) {
    console.log(chalk.cyan('[BOOT] starting owner session (./session)'));
    startSession(pairing.LEGACY_ID, { source: 'legacy' })
      .catch(e => console.log(`[SESSION main] failed: ${e.message}`));
  }

  // 2) Reload every previously paired session.
  const saved = pairing.listSessions().filter(id => id !== pairing.LEGACY_ID);
  console.log(chalk.cyan(`[BOOT] reloading ${saved.length} paired session(s)`));
  saved.forEach((sid, i) => {
    const meta = pairing.ownerOf(sid);
    setTimeout(() => {
      startSession(sid, {
        source: sid.startsWith('web_') ? 'website' : 'telegram',
        tgChatId: (meta && meta.tgChatId) || null,
        tgUserId: (meta && meta.tgUserId) || null,
      }).catch(e => console.log(`[SESSION ${sid}] start failed: ${e.message}`));
    }, i * 1500);
  });

  // 3) Website pairing bridge (Neon: varnox_pairing_requests).
  startWebsitePairingLoop((sessionId, phone, codeCb) =>
    startSession(sessionId, {
      pairPhone: phone,
      source: 'website',
      onPairingCode: async (code) => { await codeCb(code); },
    }).catch(e => console.log('[WEBSITE-PAIR] start failed: ' + e.message))
  );

  // 4) Varnox channel (the token API). This is what makes "Start" in Varnox work: the bot polls
  //    /api/v1/inbox with its own token and answers through the same API, so it needs no inbound
  //    port and nothing has to reach this container from outside.
  //    `pairing` is what lets /pair work: startSession creates the WhatsApp session, and query
  //    lets it register the request in the same queue the website bridge above drains, so the
  //    number ends up in Varnox rather than only in this process.
  //    `query` is passed only when there is a pool behind it, so /pair knows up front whether it
  //    can register the request with Varnox or has to fall back to starting the session itself.
  startVarnoxBotLoop({
    handler: EliteProHandler,
    // getWASocket lets /pair tell "already linked" from "WhatsApp refused", which are the same
    // symptom with completely different fixes.
    pairing: { startSession, query: hasDatabase ? query : null, getWASocket },
  });

  if (!TELEGRAM_TOKEN) {
    console.log(chalk.yellow('[TELEGRAM] TELEGRAM_TOKEN not set - Telegram pairing disabled.'));
  }
}

launch().catch(e => console.log('LAUNCH FAILED:', e && e.message));

// ── exported so tooling/tests can drive a session directly ────
module.exports = { startSession, pairing, launch };
